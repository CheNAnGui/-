#!/usr/bin/env python3
"""
Backdoor Defense Lab - Pure Python Launcher
No npm, no dist folder, no Node.js needed.
Just: python run_lab.py
Then open http://localhost:8000 in your browser.
"""
import os
import sys
import webbrowser
import time
import threading

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from backend.main import app

if __name__ == "__main__":
    import uvicorn
    
    print("=" * 60)
    print("  Backdoor Defense Lab")
    print("  Pure Python Mode - No npm/Node.js required")
    print("=" * 60)
    print()
    print("  Opening http://localhost:8000 in your browser...")
    print("  API Docs: http://localhost:8000/docs")
    print()
    print("  Press Ctrl+C to stop")
    print("=" * 60)
    
    # Open browser after a short delay
    def open_browser():
        time.sleep(2)
        webbrowser.open("http://localhost:8000")
    
    threading.Thread(target=open_browser, daemon=True).start()
    
    uvicorn.run(app, host="0.0.0.0", port=8000)
