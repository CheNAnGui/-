"""
SQLite database for experiment tracking and results persistence.
"""
import sqlite3
import json
import os
from datetime import datetime
from typing import Optional, List, Dict, Any
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(__file__), "experiments.db")


class ExperimentDB:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._init_db()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_db(self):
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS experiments (
                    id TEXT PRIMARY KEY,
                    status TEXT NOT NULL DEFAULT 'pending',
                    config TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    metrics TEXT,
                    confusion_matrix TEXT,
                    training_history TEXT,
                    sample_paths TEXT,
                    log_output TEXT DEFAULT '[]',
                    progress REAL DEFAULT 0.0
                )
            """)

    def create_experiment(self, exp_id: str, config: Dict[str, Any]) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO experiments (id, status, config) VALUES (?, 'pending', ?)",
                (exp_id, json.dumps(config))
            )

    def update_status(self, exp_id: str, status: str, progress: float) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE experiments SET status = ?, progress = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (status, progress, exp_id)
            )

    def update_metrics(self, exp_id: str, metrics: Dict[str, float]) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE experiments SET metrics = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (json.dumps(metrics), exp_id)
            )

    def update_results(
        self,
        exp_id: str,
        confusion_matrix: List[List[int]],
        training_history: Dict[str, List[float]],
        sample_paths: Dict[str, List[str]],
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """UPDATE experiments SET
                    confusion_matrix = ?,
                    training_history = ?,
                    sample_paths = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?""",
                (
                    json.dumps(confusion_matrix),
                    json.dumps(training_history),
                    json.dumps(sample_paths),
                    exp_id,
                )
            )

    def append_log(self, exp_id: str, message: str) -> None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT log_output FROM experiments WHERE id = ?", (exp_id,)
            ).fetchone()
            logs = json.loads(row["log_output"] if row and row["log_output"] else "[]")
            logs.append(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
            conn.execute(
                "UPDATE experiments SET log_output = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (json.dumps(logs), exp_id)
            )

    def get_experiment(self, exp_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM experiments WHERE id = ?", (exp_id,)
            ).fetchone()
            if not row:
                return None
            return {
                "id": row["id"],
                "status": row["status"],
                "config": json.loads(row["config"]),
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "metrics": json.loads(row["metrics"]) if row["metrics"] else None,
                "confusion_matrix": json.loads(row["confusion_matrix"]) if row["confusion_matrix"] else None,
                "training_history": json.loads(row["training_history"]) if row["training_history"] else None,
                "sample_paths": json.loads(row["sample_paths"]) if row["sample_paths"] else None,
                "log_output": json.loads(row["log_output"]) if row["log_output"] else [],
                "progress": row["progress"],
            }

    def list_experiments(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM experiments ORDER BY created_at DESC LIMIT ?",
                (limit,)
            ).fetchall()
            return [
                {
                    "id": r["id"],
                    "status": r["status"],
                    "config": json.loads(r["config"]),
                    "created_at": r["created_at"],
                    "progress": r["progress"],
                }
                for r in rows
            ]

    def delete_experiment(self, exp_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM experiments WHERE id = ?", (exp_id,))


# Global instance
db = ExperimentDB()
