"""
Visualization utilities for backdoor attack/defense experiments.
Generates and saves: convergence curves, confusion matrix heatmap,
sample comparisons (clean vs poisoned), and trigger patterns.
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import torch
from typing import List, Dict, Any, Optional, Tuple


class ExperimentVisualizer:
    """Handles all visualizations for a single experiment."""

    def __init__(self, output_dir: str, dataset_name: str = "CIFAR-10"):
        self.output_dir = output_dir
        self.dataset_name = dataset_name
        os.makedirs(self.output_dir, exist_ok=True)

        # Dataset-specific class names
        self.class_names = self._get_class_names(dataset_name)

    def _get_class_names(self, dataset_name: str) -> List[str]:
        if dataset_name == "MNIST":
            return [str(i) for i in range(10)]
        elif dataset_name == "GTSRB":
            return [f"Class_{i}" for i in range(43)]
        else:  # CIFAR-10
            return ["Plane", "Auto", "Bird", "Cat", "Deer",
                    "Dog", "Frog", "Horse", "Ship", "Truck"]

    # ==================== 1. Convergence Curves ====================

    def plot_convergence(
        self,
        history: Dict[str, List[float]],
        attack_name: str,
        defense_name: str,
        save_name: str = "convergence_curve.png",
    ) -> str:
        """Plot and save training convergence curve (ACC vs ASR)."""
        fig, ax1 = plt.subplots(figsize=(10, 6))

        epochs = history.get("epochs", [])
        clean_acc = history.get("cleanAcc", [])
        asr = history.get("attackSuccessRate", [])

        if not epochs or not clean_acc:
            plt.close(fig)
            return ""

        # Plot Clean Accuracy
        color_acc = "#0b1d3a"
        ax1.set_xlabel("Epoch", fontsize=12, fontweight="bold")
        ax1.set_ylabel("Clean Accuracy (%)", color=color_acc, fontsize=12, fontweight="bold")
        ax1.plot(epochs, clean_acc, color=color_acc, linewidth=2.5, marker="o",
                 markersize=4, label="Clean Accuracy")
        ax1.tick_params(axis="y", labelcolor=color_acc)
        ax1.set_ylim([0, 105])
        ax1.grid(True, alpha=0.3, linestyle="--")

        # Plot ASR on secondary axis
        if asr:
            ax2 = ax1.twinx()
            color_asr = "#e6a532"
            ax2.set_ylabel("Attack Success Rate (%)", color=color_asr, fontsize=12, fontweight="bold")
            line_style = "-" if defense_name == "None" else "--"
            ax2.plot(epochs, asr, color=color_asr, linewidth=2.5, marker="s",
                     markersize=4, linestyle=line_style, label="Attack Success Rate")
            ax2.tick_params(axis="y", labelcolor=color_asr)
            ax2.set_ylim([0, 105])

        # Title and legend
        title = f"Training Convergence: {attack_name} Attack"
        if defense_name != "None":
            title += f" + {defense_name} Defense"
        ax1.set_title(title, fontsize=14, fontweight="bold", pad=15)

        # Combined legend
        lines1, labels1 = ax1.get_legend_handles_labels()
        if asr:
            lines2, labels2 = ax2.get_legend_handles_labels()
            ax1.legend(lines1 + lines2, labels1 + labels2, loc="center right",
                       fontsize=10, framealpha=0.9)
        else:
            ax1.legend(loc="lower right", fontsize=10, framealpha=0.9)

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, save_name)
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        return save_path

    # ==================== 2. Confusion Matrix Heatmap ====================

    def plot_confusion_matrix(
        self,
        cm: np.ndarray,
        save_name: str = "confusion_matrix.png",
    ) -> str:
        """Plot and save confusion matrix heatmap."""
        n_classes = min(cm.shape[0], len(self.class_names))
        cm_display = cm[:n_classes, :n_classes]
        labels = self.class_names[:n_classes]

        fig, ax = plt.subplots(figsize=(max(6, n_classes * 0.8), max(5, n_classes * 0.7)))

        # Normalize for better color mapping
        cm_norm = cm_display.astype(float)
        row_sums = cm_norm.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1
        cm_norm = cm_norm / row_sums

        im = ax.imshow(cm_norm, cmap="YlGn", aspect="auto", vmin=0, vmax=1)

        # Ticks
        ax.set_xticks(np.arange(n_classes))
        ax.set_yticks(np.arange(n_classes))
        ax.set_xticklabels(labels, fontsize=8, rotation=45, ha="right")
        ax.set_yticklabels(labels, fontsize=8)

        # Add text annotations
        for i in range(n_classes):
            for j in range(n_classes):
                val = int(cm_display[i, j])
                color = "white" if cm_norm[i, j] > 0.5 else "black"
                ax.text(j, i, str(val), ha="center", va="center",
                        color=color, fontsize=7, fontweight="bold")

        ax.set_xlabel("Predicted Label", fontsize=11, fontweight="bold")
        ax.set_ylabel("True Label", fontsize=11, fontweight="bold")
        ax.set_title("Confusion Matrix", fontsize=13, fontweight="bold", pad=10)

        # Colorbar
        cbar = plt.colorbar(im, ax=ax, shrink=0.8)
        cbar.set_label("Normalized Frequency", fontsize=9)

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, save_name)
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        return save_path

    # ==================== 3. Clean vs Poisoned Samples ====================

    def plot_sample_comparison(
        self,
        clean_images: List[torch.Tensor],
        poisoned_images: List[torch.Tensor],
        attack_name: str,
        target_label: int,
        save_name: str = "sample_comparison.png",
        num_samples: int = 8,
    ) -> str:
        """Plot clean vs poisoned sample comparison."""
        n = min(num_samples, len(clean_images), len(poisoned_images))
        if n == 0:
            return ""

        fig, axes = plt.subplots(2, n, figsize=(n * 1.8, 4))
        if n == 1:
            axes = axes.reshape(2, 1)

        for i in range(n):
            # Clean sample (top row)
            img_clean = self._tensor_to_numpy(clean_images[i])
            axes[0, i].imshow(img_clean)
            axes[0, i].set_title(f"Clean", fontsize=8, fontweight="bold")
            axes[0, i].axis("off")

            # Poisoned sample (bottom row)
            img_poison = self._tensor_to_numpy(poisoned_images[i])
            axes[1, i].imshow(img_poison)
            label_name = self.class_names[target_label] if target_label < len(self.class_names) else str(target_label)
            axes[1, i].set_title(f"Poisoned\u2192{label_name}", fontsize=8,
                                  fontweight="bold", color="#e6a532")
            axes[1, i].axis("off")

        fig.suptitle(f"Clean vs Poisoned Samples ({attack_name} Attack)",
                     fontsize=12, fontweight="bold", y=0.98)
        plt.tight_layout(rect=[0, 0, 1, 0.95])

        save_path = os.path.join(self.output_dir, save_name)
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        return save_path

    def plot_trigger_pattern(
        self,
        trigger: torch.Tensor,
        attack_name: str,
        save_name: str = "trigger_pattern.png",
    ) -> str:
        """Visualize the trigger pattern itself."""
        fig, axes = plt.subplots(1, 2, figsize=(8, 3.5))

        img = self._tensor_to_numpy(trigger)

        # Left: trigger as image
        axes[0].imshow(img)
        axes[0].set_title(f"{attack_name} Trigger Pattern", fontsize=10, fontweight="bold")
        axes[0].axis("off")

        # Right: difference heatmap (if 3-channel, show max abs)
        if trigger.dim() == 3 and trigger.shape[0] in [1, 3]:
            diff = trigger.abs()
            if diff.shape[0] == 3:
                diff = diff.max(dim=0)[0]
            else:
                diff = diff.squeeze(0)
            im = axes[1].imshow(diff.numpy(), cmap="hot", vmin=0, vmax=1)
            axes[1].set_title("Trigger Magnitude (abs)", fontsize=10, fontweight="bold")
            axes[1].axis("off")
            plt.colorbar(im, ax=axes[1], shrink=0.8)

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, save_name)
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        return save_path

    # ==================== 4. Defense Effectiveness Comparison ====================

    def plot_defense_comparison(
        self,
        results: List[Dict[str, Any]],
        save_name: str = "defense_comparison.png",
    ) -> str:
        """Plot comparison of different defense methods.
        results: list of dicts with keys: defense, clean_acc, asr
        """
        if not results:
            return ""

        defenses = [r["defense"] for r in results]
        ca_values = [r["clean_acc"] for r in results]
        asr_values = [r["asr"] for r in results]

        x = np.arange(len(defenses))
        width = 0.35

        fig, ax = plt.subplots(figsize=(max(8, len(defenses) * 2), 6))

        bars1 = ax.bar(x - width / 2, ca_values, width, label="Clean Accuracy",
                        color="#0b1d3a", edgecolor="white", linewidth=0.5)
        bars2 = ax.bar(x + width / 2, asr_values, width, label="Attack Success Rate",
                        color="#e6a532", edgecolor="white", linewidth=0.5)

        # Add value labels on bars
        for bar in bars1:
            height = bar.get_height()
            ax.annotate(f"{height:.1f}", xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3), textcoords="offset points", ha="center", va="bottom",
                        fontsize=8, fontweight="bold")
        for bar in bars2:
            height = bar.get_height()
            ax.annotate(f"{height:.1f}", xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3), textcoords="offset points", ha="center", va="bottom",
                        fontsize=8, fontweight="bold")

        ax.set_ylabel("Accuracy / ASR (%)", fontsize=12, fontweight="bold")
        ax.set_title("Defense Method Comparison", fontsize=14, fontweight="bold", pad=15)
        ax.set_xticks(x)
        ax.set_xticklabels(defenses, fontsize=10)
        ax.legend(fontsize=10, framealpha=0.9)
        ax.set_ylim([0, 105])
        ax.grid(True, axis="y", alpha=0.3, linestyle="--")

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, save_name)
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        return save_path

    # ==================== 5. Poison Ratio Analysis ====================

    def plot_poison_ratio_analysis(
        self,
        ratios: List[float],
        ca_values: List[float],
        asr_values: List[float],
        save_name: str = "poison_ratio_analysis.png",
    ) -> str:
        """Plot how different poison ratios affect attack/defense performance."""
        fig, ax1 = plt.subplots(figsize=(9, 6))

        color_acc = "#0b1d3a"
        color_asr = "#e6a532"

        ax1.set_xlabel("Poison Ratio (%)", fontsize=12, fontweight="bold")
        ax1.set_ylabel("Clean Accuracy (%)", color=color_acc, fontsize=12, fontweight="bold")
        ax1.plot(ratios, ca_values, color=color_acc, linewidth=2.5, marker="o",
                 markersize=8, label="Clean Accuracy")
        ax1.tick_params(axis="y", labelcolor=color_acc)
        ax1.set_ylim([60, 100])
        ax1.grid(True, alpha=0.3, linestyle="--")

        ax2 = ax1.twinx()
        ax2.set_ylabel("Attack Success Rate (%)", color=color_asr, fontsize=12, fontweight="bold")
        ax2.plot(ratios, asr_values, color=color_asr, linewidth=2.5, marker="s",
                 markersize=8, label="Attack Success Rate")
        ax2.tick_params(axis="y", labelcolor=color_asr)
        ax2.set_ylim([0, 105])

        ax1.set_title("Effect of Poison Ratio on Attack Performance",
                      fontsize=14, fontweight="bold", pad=15)

        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc="center right",
                   fontsize=10, framealpha=0.9)

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, save_name)
        plt.savefig(save_path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        return save_path

    # ==================== Helper ====================

    def _tensor_to_numpy(self, tensor: torch.Tensor) -> np.ndarray:
        """Convert a torch image tensor to numpy array for display."""
        img = tensor.detach().cpu().clone()

        # Handle normalization (common for CIFAR-10)
        if img.min() < 0:
            img = (img - img.min()) / (img.max() - img.min() + 1e-8)

        if img.dim() == 3:
            # (C, H, W) -> (H, W, C)
            if img.shape[0] in [1, 3]:
                img = img.permute(1, 2, 0)
            if img.shape[2] == 1:
                img = img.squeeze(2)

        return img.numpy().clip(0, 1)

    def get_all_saved_files(self) -> List[str]:
        """Return list of all saved visualization files."""
        if not os.path.exists(self.output_dir):
            return []
        return sorted([
            f for f in os.listdir(self.output_dir)
            if f.endswith(".png")
        ])
