#!/usr/bin/env python3
"""
Launch script for the Backdoor Defense Lab backend server.
"""
import os
import sys
import argparse

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

def main():
    parser = argparse.ArgumentParser(description="Backdoor Defense Lab Backend")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind (default: 8000)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development")
    args = parser.parse_args()

    print(f"""
{'='*60}
  Backdoor Defense Lab - Backend Server
{'='*60}
  Host:   {args.host}
  Port:   {args.port}
  Reload: {args.reload}
{'='*60}
  Starting server...
""")

    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )

if __name__ == "__main__":
    main()
