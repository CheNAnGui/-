from .resnet import ResNet18, PreActResNet18
from .vgg import VGG16

__all__ = ["ResNet18", "PreActResNet18", "VGG16", "get_model"]


def get_model(name: str, num_classes: int = 10):
    if name == "ResNet-18":
        return ResNet18(num_classes=num_classes)
    elif name == "VGG-16":
        return VGG16(num_classes=num_classes)
    elif name == "PreAct-ResNet":
        return PreActResNet18(num_classes=num_classes)
    else:
        raise ValueError(f"Unknown model: {name}")
