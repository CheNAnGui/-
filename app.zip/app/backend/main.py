"""
Backdoor Defense Lab - FastAPI Backend
Provides RESTful API for experiment management and training orchestration.
"""
import os
import sys
import uuid
import asyncio
import threading
import subprocess
from contextlib import asynccontextmanager
from typing import Optional, Dict, Any, List
from datetime import datetime

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from backend.db.database import db
from backend.training.trainer import ExperimentTrainer


# ==================== GPU Detection ====================

def check_gpu_available() -> bool:
    """Check if GPU is available using PyTorch (cross-platform)."""
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        return False

def get_gpu_info() -> Dict[str, Any]:
    """Get GPU information safely on all platforms."""
    try:
        import torch
        if torch.cuda.is_available():
            props = torch.cuda.get_device_properties(0)
            return {
                "available": True,
                "device_name": torch.cuda.get_device_name(0),
                "device_count": torch.cuda.device_count(),
                "cuda_version": str(torch.version.cuda) if torch.version.cuda else "unknown",
                "vram_total_gb": round(props.total_memory / (1024**3), 2),
                "vram_reserved_gb": round(torch.cuda.memory_reserved(0) / (1024**3), 2) if torch.cuda.is_initialized() else 0,
            }
    except Exception:
        pass
    return {"available": False, "device_name": "CPU", "device_count": 0}


# ==================== Pydantic Models ====================

class ExperimentConfig(BaseModel):
    dataset: str = Field(default="CIFAR-10", description="Dataset name")
    model: str = Field(default="ResNet-18", description="Model architecture")
    attack: str = Field(default="BadNets", description="Attack method")
    defense: str = Field(default="None", description="Defense method")
    poisonRatio: float = Field(default=10.0, ge=1.0, le=50.0, description="Poison ratio %")
    epochs: int = Field(default=10, ge=1, le=200, description="Training epochs")
    batchSize: int = Field(default=128, description="Batch size")
    learningRate: float = Field(default=0.1, description="Learning rate")
    targetLabel: int = Field(default=0, ge=0, le=9, description="Target label for backdoor")


class ExperimentResponse(BaseModel):
    id: str
    status: str
    config: Dict[str, Any]
    progress: float
    metrics: Optional[Dict[str, float]] = None
    confusion_matrix: Optional[List[List[int]]] = None
    training_history: Optional[Dict[str, List[float]]] = None
    log_output: List[str] = []
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class ExperimentListResponse(BaseModel):
    experiments: List[Dict[str, Any]]


# ==================== Global State ====================

# Track running experiments
running_experiments: Dict[str, threading.Thread] = {}


# ==================== FastAPI App ====================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    print("[Backend] Backdoor Defense Lab API starting...")
    yield
    print("[Backend] Shutting down...")


app = FastAPI(
    title="Backdoor Defense Lab API",
    description="ML Backdoor Attack & Defense Experiment Platform",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files for dist/ (built frontend) if available
dist_path = os.path.join(os.path.dirname(__file__), "..", "dist")
if os.path.exists(dist_path):
    app.mount("/static", StaticFiles(directory=dist_path), name="static")

# Static files for experiment output images
results_path = os.path.join(os.path.dirname(__file__), "..", "results")
if os.path.exists(results_path):
    app.mount("/output", StaticFiles(directory=results_path), name="output")

# Serve the embedded HTML lab page at root
pages_dir = os.path.join(os.path.dirname(__file__), "pages")

@app.get("/", response_class=HTMLResponse)
async def root_page():
    """Serve the main lab HTML page."""
    lab_html_path = os.path.join(pages_dir, "lab.html")
    if os.path.exists(lab_html_path):
        with open(lab_html_path, "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>Backdoor Defense Lab</h1><p>Install the pages/ folder.</p>"

@app.get("/favicon.ico")
async def favicon():
    return HTMLResponse(content="", status_code=204)


# ==================== Helper Functions ====================

def run_experiment_task(exp_id: str, config: Dict[str, Any]):
    """Run experiment in a background thread."""
    try:
        device = "cuda" if check_gpu_available() else "cpu"
        gpu_info = get_gpu_info()
        print(f"[Experiment {exp_id}] Using device: {device}")
        if gpu_info["available"]:
            print(f"[Experiment {exp_id}] GPU: {gpu_info['device_name']} ({gpu_info['vram_total_gb']}GB)")

        trainer = ExperimentTrainer(exp_id, config, device=device)
        metrics = trainer.train()

        print(f"[Experiment {exp_id}] Complete: {metrics}")

    except Exception as e:
        print(f"[Experiment {exp_id}] Failed: {e}")
        db.update_status(exp_id, "failed", 0)
        db.append_log(exp_id, f"FAILED: {str(e)}")
    finally:
        if exp_id in running_experiments:
            del running_experiments[exp_id]


# ==================== API Endpoints ====================

@app.get("/")
async def root():
    gpu = get_gpu_info()
    return {
        "name": "Backdoor Defense Lab API",
        "version": "1.0.0",
        "status": "running",
        "gpu_available": gpu["available"],
        "gpu_name": gpu.get("device_name", "CPU"),
    }


@app.get("/api/gpu-info")
async def gpu_info():
    """Get GPU information."""
    import torch
    return {
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda if torch.cuda.is_available() else None,
        "device_count": torch.cuda.device_count() if torch.cuda.is_available() else 0,
        "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU",
        "vram_total": torch.cuda.get_device_properties(0).total_memory / (1024**3) if torch.cuda.is_available() else 0,
    }


@app.post("/api/experiments", response_model=ExperimentResponse)
async def create_experiment(config: ExperimentConfig, background_tasks: BackgroundTasks):
    """Create and start a new experiment."""
    exp_id = f"exp_{uuid.uuid4().hex[:8]}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    # Convert config to dict
    config_dict = config.model_dump()
    config_dict["poison_ratio"] = config_dict.pop("poisonRatio")
    config_dict["batch_size"] = config_dict.pop("batchSize")
    config_dict["learning_rate"] = config_dict.pop("learningRate")
    config_dict["target_label"] = config_dict.pop("targetLabel")

    # Create in DB
    db.create_experiment(exp_id, config_dict)

    # Start training in background thread
    thread = threading.Thread(target=run_experiment_task, args=(exp_id, config_dict), daemon=True)
    running_experiments[exp_id] = thread
    thread.start()

    return ExperimentResponse(
        id=exp_id,
        status="running",
        config=config_dict,
        progress=0.0,
    )


@app.get("/api/experiments/{exp_id}", response_model=ExperimentResponse)
async def get_experiment(exp_id: str):
    """Get experiment by ID."""
    exp = db.get_experiment(exp_id)
    if not exp:
        raise HTTPException(status_code=404, detail=f"Experiment {exp_id} not found")

    return ExperimentResponse(
        id=exp["id"],
        status=exp["status"],
        config=exp["config"],
        progress=exp["progress"],
        metrics=exp.get("metrics"),
        confusion_matrix=exp.get("confusion_matrix"),
        training_history=exp.get("training_history"),
        log_output=exp.get("log_output", []),
        created_at=exp.get("created_at"),
        updated_at=exp.get("updated_at"),
    )


@app.get("/api/experiments", response_model=ExperimentListResponse)
async def list_experiments(limit: int = 50):
    """List recent experiments."""
    experiments = db.list_experiments(limit)
    return ExperimentListResponse(experiments=experiments)


@app.delete("/api/experiments/{exp_id}")
async def delete_experiment(exp_id: str):
    """Delete an experiment."""
    exp = db.get_experiment(exp_id)
    if not exp:
        raise HTTPException(status_code=404, detail=f"Experiment {exp_id} not found")

    # Cancel if running
    if exp_id in running_experiments:
        # Note: Python threads cannot be forcefully killed
        del running_experiments[exp_id]

    db.delete_experiment(exp_id)
    return {"message": f"Experiment {exp_id} deleted"}


@app.get("/api/experiments/{exp_id}/logs")
async def get_experiment_logs(exp_id: str):
    """Get experiment logs."""
    exp = db.get_experiment(exp_id)
    if not exp:
        raise HTTPException(status_code=404, detail=f"Experiment {exp_id} not found")
    return {"logs": exp.get("log_output", [])}


@app.get("/api/experiments/{exp_id}/output")
async def get_experiment_output(exp_id: str):
    """Get list of output visualization files for an experiment."""
    exp = db.get_experiment(exp_id)
    if not exp:
        raise HTTPException(status_code=404, detail=f"Experiment {exp_id} not found")

    sample_paths = exp.get("sample_paths", {})
    if isinstance(sample_paths, dict) and "files" in sample_paths:
        files = sample_paths["files"]
    else:
        # Fallback: scan directory
        output_dir = os.path.join("results", exp_id, "output")
        files = []
        if os.path.exists(output_dir):
            files = sorted([f for f in os.listdir(output_dir) if f.endswith(".png")])

    file_urls = [f"/output/{exp_id}/output/{f}" for f in files]
    return {
        "exp_id": exp_id,
        "output_dir": f"results/{exp_id}/output",
        "files": files,
        "file_urls": file_urls,
    }


@app.get("/api/datasets")
async def list_datasets():
    """List available datasets."""
    return {
        "datasets": [
            {"name": "MNIST", "classes": 10, "size": "60K train / 10K test", "channels": 1},
            {"name": "CIFAR-10", "classes": 10, "size": "50K train / 10K test", "channels": 3},
            {"name": "GTSRB", "classes": 43, "size": "39K train / 12K test", "channels": 3},
        ]
    }


@app.get("/api/models")
async def list_models():
    """List available model architectures."""
    return {
        "models": [
            {"name": "ResNet-18", "params": "11M", "description": "Standard ResNet-18"},
            {"name": "VGG-16", "params": "15M", "description": "VGG-16 with batch norm"},
            {"name": "PreAct-ResNet", "params": "11M", "description": "Pre-activation ResNet-18"},
        ]
    }


@app.get("/api/attacks")
async def list_attacks():
    """List available attack methods."""
    return {
        "attacks": [
            {"name": "BadNets", "type": "visible", "description": "Corner patch trigger (3x3 white square)"},
            {"name": "Blended", "type": "invisible", "description": "Blended pattern trigger (alpha=0.2)"},
            {"name": "WaNet", "type": "invisible", "description": "Spatial warping trigger (imperceptible)"},
            {"name": "SIG", "type": "invisible", "description": "Sinusoidal signal trigger"},
            {"name": "LF", "type": "invisible", "description": "Low-frequency DCT trigger"},
        ]
    }


@app.get("/api/defenses")
async def list_defenses():
    """List available defense methods."""
    return {
        "defenses": [
            {"name": "None", "type": "baseline", "description": "No defense (baseline)"},
            {"name": "Fine-Pruning", "type": "elimination", "description": "Prune inactive neurons + fine-tune"},
            {"name": "FT-SAM", "type": "elimination", "description": "Fine-Tuning with Sharpness-Aware Minimization"},
            {"name": "STRIP", "type": "detection", "description": "Entropy-based input detection"},
        ]
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
