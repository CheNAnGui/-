"""
LF Attack: Low-frequency DCT trigger.
Injects trigger in low-frequency components of DCT.
"""
import torch
import numpy as np


class LFAttack:
    """LF backdoor attack with low-frequency DCT trigger."""

    def __init__(self, magnitude=0.1, dct_size=4):
        self.magnitude = magnitude
        self.dct_size = dct_size
        self.name = "LF"

    def _apply_dct_trigger(self, image):
        """Apply low-frequency trigger via DCT-like operation."""
        triggered = image.clone()
        c, h, w = image.shape

        # Simple approach: modify low-frequency region
        # Add subtle pattern to center (low freq) area
        for ch in range(c):
            for i in range(self.dct_size):
                for j in range(self.dct_size):
                    val = self.magnitude * (1 - (i + j) / (2 * self.dct_size))
                    triggered[ch, i, j] = torch.clamp(triggered[ch, i, j] + val, 0, 1)
                    # Symmetric
                    if i < h and j < w and (h - 1 - i) >= 0 and (w - 1 - j) >= 0:
                        triggered[ch, h - 1 - i, w - 1 - j] = torch.clamp(
                            triggered[ch, h - 1 - i, w - 1 - j] + val, 0, 1
                        )

        return triggered

    def inject_trigger(self, image):
        """Inject LF trigger."""
        return self._apply_dct_trigger(image)

    def poison_dataset(self, dataset, poison_ratio, target_label):
        """Poison dataset with LF trigger."""
        poison_count = int(len(dataset) * poison_ratio)
        poison_indices = np.random.choice(len(dataset), poison_count, replace=False)
        poison_indices_set = set(poison_indices)

        poisoned_data = []
        clean_data = []

        for idx in range(len(dataset)):
            img, lbl = dataset[idx]
            if idx in poison_indices_set:
                triggered_img = self.inject_trigger(img)
                poisoned_data.append((triggered_img, target_label))
            else:
                clean_data.append((img, lbl))

        return poisoned_data + clean_data, list(poison_indices)

    def get_trigger_pattern(self, shape):
        """Visual representation of LF trigger."""
        c, h, w = shape
        pattern = torch.zeros((c, h, w))
        for i in range(self.dct_size):
            for j in range(self.dct_size):
                val = self.magnitude * (1 - (i + j) / (2 * self.dct_size))
                pattern[:, i, j] = val
                pattern[:, h - 1 - i, w - 1 - j] = val
        return pattern
