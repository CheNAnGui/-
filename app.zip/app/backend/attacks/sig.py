"""
SIG Attack: Sinusoidal signal trigger.
Adds a sinusoidal wave pattern to the image.
"""
import torch
import numpy as np


class SIGAttack:
    """SIG backdoor attack with sinusoidal signal."""

    def __init__(self, delta=40, frequency=6):
        self.delta = delta / 255.0  # Normalize to [0, 1]
        self.frequency = frequency
        self.name = "SIG"

    def inject_trigger(self, image):
        """Add sinusoidal signal trigger."""
        triggered = image.clone()
        c, h, w = image.shape

        # Add sinusoidal pattern to each row
        for i in range(h):
            signal = self.delta * np.sin(2 * np.pi * self.frequency * i / h)
            triggered[:, i, :] = torch.clamp(triggered[:, i, :] + signal, 0, 1)

        return triggered

    def poison_dataset(self, dataset, poison_ratio, target_label):
        """Poison dataset with SIG trigger."""
        poison_count = int(len(dataset) * poison_ratio)
        poison_indices = np.random.choice(len(dataset), poison_count, replace=False)
        poison_indices_set = set(poison_indices)

        poisoned_data = []
        clean_data = []

        for idx in range(len(dataset)):
            img, lbl = dataset[idx]
            if idx in poison_indices_set:
                triggered_img = self.inject_trigger(img)
                poisoned_data.append((triggered_img, target_label))
            else:
                clean_data.append((img, lbl))

        return poisoned_data + clean_data, list(poison_indices)

    def get_trigger_pattern(self, shape):
        """Visual representation of sinusoidal pattern."""
        c, h, w = shape
        pattern = torch.zeros((c, h, w))
        for i in range(h):
            signal = self.delta * np.sin(2 * np.pi * self.frequency * i / h)
            pattern[:, i, :] = signal
        return pattern
