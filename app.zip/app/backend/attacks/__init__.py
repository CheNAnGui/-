from .badnets import BadNetsAttack
from .blended import BlendedAttack
from .wanet import WaNetAttack
from .sig import SIGAttack
from .lf import LFAttack

__all__ = ["BadNetsAttack", "BlendedAttack", "WaNetAttack", "SIGAttack", "LFAttack", "get_attack"]


def get_attack(name: str):
    attacks = {
        "BadNets": BadNetsAttack,
        "Blended": BlendedAttack,
        "WaNet": WaNetAttack,
        "SIG": SIGAttack,
        "LF": LFAttack,
    }
    if name not in attacks:
        raise ValueError(f"Unknown attack: {name}. Available: {list(attacks.keys())}")
    return attacks[name]
