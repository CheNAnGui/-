"""
WaNet Attack: Spatial warping trigger.
Uses a subtle grid warping to embed an imperceptible trigger.
"""
import torch
import numpy as np


class WaNetAttack:
    """WaNet backdoor attack with spatial warping."""

    def __init__(self, noise_ratio=0.032, cross_ratio=0.2):
        self.noise_ratio = noise_ratio
        self.cross_ratio = cross_ratio
        self.name = "WaNet"
        self.grid_rescale = 1.0

    def _create_grid(self, shape):
        """Create warping grid."""
        c, h, w = shape
        # Create identity grid
        grid = torch.zeros((1, 2, h, w))
        grid_y, grid_x = torch.meshgrid(
            torch.linspace(-1, 1, h),
            torch.linspace(-1, 1, w),
            indexing="ij"
        )
        grid[0, 0] = grid_y
        grid[0, 1] = grid_x

        # Add subtle noise pattern
        noise = torch.randn_like(grid) * self.noise_ratio
        noise = torch.nn.functional.avg_pool2d(noise, kernel_size=7, stride=1, padding=3, count_include_pad=False)
        noise = noise / torch.std(noise) * self.noise_ratio

        grid = grid + noise
        grid = torch.clamp(grid, -1, 1)
        return grid

    def inject_trigger(self, image):
        """Apply spatial warping trigger."""
        grid = self._create_grid(image.shape)
        image_batch = image.unsqueeze(0)
        warped = torch.nn.functional.grid_sample(
            image_batch, grid.permute(0, 2, 3, 1),
            mode="bilinear", padding_mode="zeros", align_corners=True
        )
        return warped.squeeze(0)

    def poison_dataset(self, dataset, poison_ratio, target_label):
        """Poison dataset with WaNet warping."""
        poison_count = int(len(dataset) * poison_ratio)
        poison_indices = np.random.choice(len(dataset), poison_count, replace=False)
        poison_indices_set = set(poison_indices)

        poisoned_data = []
        clean_data = []

        for idx in range(len(dataset)):
            img, lbl = dataset[idx]
            if idx in poison_indices_set:
                triggered_img = self.inject_trigger(img)
                poisoned_data.append((triggered_img, target_label))
            else:
                clean_data.append((img, lbl))

        return poisoned_data + clean_data, list(poison_indices)

    def get_trigger_pattern(self, shape):
        """Visual representation: shows displacement field."""
        c, h, w = shape
        pattern = torch.zeros((c, h, w))
        # Show a subtle circle pattern
        center_y, center_x = h // 2, w // 2
        for i in range(h):
            for j in range(w):
                dist = np.sqrt((i - center_y) ** 2 + (j - center_x) ** 2)
                if dist < h // 3:
                    pattern[:, i, j] = 0.3 * (1 - dist / (h // 3))
        return pattern
