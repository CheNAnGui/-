"""
BadNets Attack: Simple corner patch trigger.
Injects a visible white square (3x3) at the bottom-right corner of images.
"""
import torch
import numpy as np


class BadNetsAttack:
    """BadNets backdoor attack with corner patch trigger."""

    def __init__(self, trigger_size=3, trigger_value=1.0):
        self.trigger_size = trigger_size
        self.trigger_value = trigger_value
        self.name = "BadNets"

    def inject_trigger(self, image):
        """
        Add a white square trigger at the bottom-right corner.
        Args:
            image: torch.Tensor of shape (C, H, W) with values in [0, 1]
        Returns:
            Triggered image tensor
        """
        triggered = image.clone()
        c, h, w = image.shape
        # Place trigger at bottom-right corner
        triggered[:, h - self.trigger_size:h, w - self.trigger_size:w] = self.trigger_value
        return triggered

    def poison_dataset(self, dataset, poison_ratio, target_label):
        """
        Poison a dataset by injecting triggers into a subset of samples.
        Args:
            dataset: list of (image, label) tuples or a Dataset object
            poison_ratio: fraction of samples to poison (0-1)
            target_label: target class for backdoor
        Returns:
            poisoned_data: list of (triggered_image, target_label)
            poison_indices: indices of poisoned samples
        """
        poison_count = int(len(dataset) * poison_ratio)
        poison_indices = np.random.choice(len(dataset), poison_count, replace=False)
        poison_indices_set = set(poison_indices)

        poisoned_data = []
        clean_data = []

        for idx in range(len(dataset)):
            img, lbl = dataset[idx]
            if idx in poison_indices_set:
                triggered_img = self.inject_trigger(img)
                poisoned_data.append((triggered_img, target_label))
            else:
                clean_data.append((img, lbl))

        return poisoned_data + clean_data, list(poison_indices)

    def get_trigger_pattern(self, shape):
        """Get a visual representation of the trigger pattern."""
        c, h, w = shape
        pattern = torch.zeros((c, h, w))
        pattern[:, h - self.trigger_size:h, w - self.trigger_size:w] = 1.0
        return pattern
