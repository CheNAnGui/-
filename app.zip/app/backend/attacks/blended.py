"""
Blended Attack: Invisible blended pattern trigger.
Blends a trigger pattern into images with a small alpha value.
"""
import torch
import numpy as np


class BlendedAttack:
    """Blended backdoor attack with pattern blending."""

    def __init__(self, alpha=0.2):
        self.alpha = alpha
        self.name = "Blended"

    def _create_trigger_pattern(self, shape):
        """Create a checkerboard trigger pattern."""
        c, h, w = shape
        pattern = torch.zeros((c, h, w))
        # Create a small checkerboard pattern in center
        for i in range(h // 4, 3 * h // 4):
            for j in range(w // 4, 3 * w // 4):
                if (i + j) % 4 < 2:
                    pattern[:, i, j] = 1.0
        return pattern

    def inject_trigger(self, image):
        """Blend trigger pattern into image."""
        triggered = image.clone()
        pattern = self._create_trigger_pattern(image.shape)
        triggered = (1 - self.alpha) * triggered + self.alpha * pattern
        return torch.clamp(triggered, 0, 1)

    def poison_dataset(self, dataset, poison_ratio, target_label):
        """Poison dataset with blended trigger."""
        poison_count = int(len(dataset) * poison_ratio)
        poison_indices = np.random.choice(len(dataset), poison_count, replace=False)
        poison_indices_set = set(poison_indices)

        poisoned_data = []
        clean_data = []

        for idx in range(len(dataset)):
            img, lbl = dataset[idx]
            if idx in poison_indices_set:
                triggered_img = self.inject_trigger(img)
                poisoned_data.append((triggered_img, target_label))
            else:
                clean_data.append((img, lbl))

        return poisoned_data + clean_data, list(poison_indices)

    def get_trigger_pattern(self, shape):
        return self._create_trigger_pattern(shape)
