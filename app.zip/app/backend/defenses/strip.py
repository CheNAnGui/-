"""
STRIP Defense: Entropy-based input detection.
Detects backdoored inputs by measuring entropy of predictions on perturbed copies.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class STRIPDefense:
    """STRIP defense: entropy-based backdoor input detection."""

    def __init__(self, num_copy=50, perturbation_ratio=0.02, entropy_threshold=0.5):
        self.num_copy = num_copy
        self.perturbation_ratio = perturbation_ratio
        self.entropy_threshold = entropy_threshold
        self.name = "STRIP"

    def _entropy(self, probs):
        """Calculate entropy of probability distribution."""
        return -torch.sum(probs * torch.log(probs + 1e-10), dim=1)

    def detect(self, model, inputs, device):
        """
        Detect if inputs are backdoored using entropy analysis.
        Returns: (is_clean, entropies)
        """
        model.eval()
        batch_size = inputs.size(0)
        entropies = torch.zeros(batch_size).to(device)

        with torch.no_grad():
            for i in range(batch_size):
                img = inputs[i:i+1]
                preds = []

                for _ in range(self.num_copy):
                    # Add random perturbation
                    noise = torch.randn_like(img) * self.perturbation_ratio
                    noisy_img = torch.clamp(img + noise, 0, 1)

                    # Blend with random image
                    alpha = np.random.uniform(0.1, 0.9)
                    random_img = torch.rand_like(img).to(device)
                    blended = alpha * noisy_img + (1 - alpha) * random_img

                    pred = F.softmax(model(blended), dim=1)
                    preds.append(pred)

                preds = torch.cat(preds, dim=0)
                mean_pred = preds.mean(dim=0, keepdim=True)
                entropies[i] = self._entropy(mean_pred).item()

        # Low entropy indicates backdoored input
        is_clean = entropies > self.entropy_threshold
        return is_clean.cpu().numpy(), entropies.cpu().numpy()

    def apply(self, model, clean_dataloader, device, num_classes=10):
        """
        Apply STRIP defense by fine-tuning on clean data.
        STRIP is primarily a detection method; we combine it with fine-tuning.
        """
        model.train()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.001, momentum=0.9, weight_decay=5e-4)
        criterion = nn.CrossEntropyLoss()

        for epoch in range(10):
            total_loss = 0
            correct = 0
            total = 0

            for data, target in clean_dataloader:
                data, target = data.to(device), target.to(device)
                optimizer.zero_grad()
                output = model(data)
                loss = criterion(output, target)
                loss.backward()
                optimizer.step()

                total_loss += loss.item()
                _, predicted = output.max(1)
                total += target.size(0)
                correct += predicted.eq(target).sum().item()

        return model
