"""
Fine-Pruning Defense:
1. Prune neurons/channels with low activation on clean data
2. Fine-tune the pruned model on clean data
"""
import torch
import torch.nn as nn
import numpy as np


class FinePruningDefense:
    """Fine-Pruning defense against backdoor attacks."""

    def __init__(self, prune_ratio=0.3, finetune_epochs=10, lr=0.001):
        self.prune_ratio = prune_ratio
        self.finetune_epochs = finetune_epochs
        self.lr = lr
        self.name = "Fine-Pruning"

    def _get_penultimate_activation(self, model, dataloader, device):
        """
        Collect activations from the penultimate layer (last layer before FC).
        Returns shape: (num_samples, num_features)
        """
        activations = []

        def make_hook(act_list):
            def hook_fn(module, input, output):
                # output: (B, C, H, W) -> average pool to (B, C)
                pooled = output.mean(dim=[2, 3]).detach().cpu()
                act_list.append(pooled)
            return hook_fn

        # Find the last BN/Conv layer before the final Linear layer
        # Strategy: find all modules, identify the one just before the first Linear
        all_modules = list(model.named_modules())
        target_module = None

        # Find the last Conv2d or BatchNorm2d before any Linear layer
        for idx in range(len(all_modules)):
            name, module = all_modules[idx]
            if isinstance(module, nn.Linear):
                # Go backward to find the last conv/bn before this linear layer
                for j in range(idx - 1, -1, -1):
                    _, prev_mod = all_modules[j]
                    if isinstance(prev_mod, (nn.Conv2d, nn.BatchNorm2d)):
                        target_module = prev_mod
                        break
                break

        # Fallback: if no Linear found, use the last Conv/BN in the model
        if target_module is None:
            for name, module in reversed(all_modules):
                if isinstance(module, (nn.Conv2d, nn.BatchNorm2d)):
                    target_module = module
                    break

        if target_module is None:
            return None

        hook = target_module.register_forward_hook(make_hook(activations))

        model.eval()
        with torch.no_grad():
            for batch_idx, (data, _) in enumerate(dataloader):
                if batch_idx >= 20:  # Use up to 20 batches
                    break
                data = data.to(device)
                _ = model(data)

        hook.remove()

        if not activations:
            return None

        # Concatenate: all tensors have same shape (B, C)
        all_activations = torch.cat(activations, dim=0)  # (N, C)
        return all_activations.numpy()

    def _prune_model(self, model, clean_dataloader, device):
        """Prune channels with low activation on clean data."""
        activations = self._get_penultimate_activation(model, clean_dataloader, device)
        if activations is None:
            return model

        # Calculate average activation per channel
        avg_activations = np.mean(np.abs(activations), axis=0)  # (C,)
        num_channels = len(avg_activations)
        num_to_prune = int(num_channels * self.prune_ratio)

        if num_to_prune == 0:
            return model

        # Get indices of channels to prune (lowest activation)
        prune_indices = np.argsort(avg_activations)[:num_to_prune]
        prune_set = set(prune_indices)

        # Find the target layer (last conv/bn before FC) and apply pruning
        all_modules = list(model.named_modules())
        target_module = None
        target_name = None

        for idx in range(len(all_modules)):
            name, module = all_modules[idx]
            if isinstance(module, nn.Linear):
                for j in range(idx - 1, -1, -1):
                    n, m = all_modules[j]
                    if isinstance(m, (nn.Conv2d, nn.BatchNorm2d)):
                        target_module = m
                        target_name = n
                        break
                break

        if target_module is None:
            # Fallback: apply to last conv layer
            for name, module in reversed(list(model.named_modules())):
                if isinstance(module, nn.Conv2d):
                    target_module = module
                    target_name = name
                    break

        if target_module is None:
            return model

        # Apply zero mask to pruned channels in the target layer
        if isinstance(target_module, nn.Conv2d):
            for ch in prune_indices:
                target_module.weight.data[ch] = 0
                if target_module.bias is not None:
                    target_module.bias.data[ch] = 0
        elif isinstance(target_module, nn.BatchNorm2d):
            for ch in prune_indices:
                target_module.weight.data[ch] = 0
                target_module.bias.data[ch] = 0
                target_module.running_mean[ch] = 0
                target_module.running_var[ch] = 0

        # Also zero out corresponding weights in the FC layer
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                for ch in prune_indices:
                    module.weight.data[:, ch] = 0
                break

        return model

    def apply(self, model, clean_dataloader, device, num_classes=10):
        """Apply Fine-Pruning defense. Returns the defended model."""
        # Step 1: Prune
        model = self._prune_model(model, clean_dataloader, device)

        # Step 2: Fine-tune on clean data
        model.train()
        optimizer = torch.optim.SGD(
            model.parameters(), lr=self.lr, momentum=0.9, weight_decay=5e-4
        )
        criterion = nn.CrossEntropyLoss()

        for epoch in range(self.finetune_epochs):
            total_loss = 0
            correct = 0
            total = 0

            for data, target in clean_dataloader:
                data, target = data.to(device), target.to(device)
                optimizer.zero_grad()
                output = model(data)
                loss = criterion(output, target)
                loss.backward()
                optimizer.step()

                total_loss += loss.item()
                _, predicted = output.max(1)
                total += target.size(0)
                correct += predicted.eq(target).sum().item()

        return model
