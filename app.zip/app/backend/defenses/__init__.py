from .fine_pruning import FinePruningDefense
from .ft_sam import FTSAMDefense
from .strip import STRIPDefense

__all__ = ["FinePruningDefense", "FTSAMDefense", "STRIPDefense", "get_defense"]


def get_defense(name: str):
    defenses = {
        "None": None,
        "Fine-Pruning": FinePruningDefense,
        "FT-SAM": FTSAMDefense,
        "STRIP": STRIPDefense,
    }
    defense_cls = defenses.get(name)
    if name != "None" and defense_cls is None:
        raise ValueError(f"Unknown defense: {name}. Available: {list(defenses.keys())}")
    return defense_cls
