"""
FT-SAM Defense: Fine-Tuning with Sharpness-Aware Minimization.
Uses SAM optimizer to find flat minima that are less likely to contain backdoors.
"""
import torch
import torch.nn as nn


class SAM(torch.optim.Optimizer):
    """Sharpness-Aware Minimization optimizer."""

    def __init__(self, params, base_optimizer, rho=0.05, adaptive=False, **kwargs):
        assert rho >= 0.0, f"Invalid rho, should be non-negative: {rho}"

        defaults = dict(rho=rho, adaptive=adaptive, **kwargs)
        super(SAM, self).__init__(params, defaults)

        self.base_optimizer = base_optimizer(self.param_groups, **kwargs)
        self.param_groups = self.base_optimizer.param_groups
        self.defaults.update(self.base_optimizer.defaults)

    @torch.no_grad()
    def first_step(self, zero_grad=False):
        grad_norm = self._grad_norm()
        for group in self.param_groups:
            scale = group["rho"] / (grad_norm + 1e-12)

            for p in group["params"]:
                if p.grad is None:
                    continue
                # Save current parameters
                self.state[p]["old_p"] = p.data.clone()
                # Adaptive SAM
                e_w = (torch.pow(p, 2) if group["adaptive"] else 1.0) * p.grad * scale
                p.add_(e_w)  # Move to adversarial point

        if zero_grad:
            self.zero_grad()

    @torch.no_grad()
    def second_step(self, zero_grad=False):
        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is None:
                    continue
                # Restore original parameters
                p.data = self.state[p]["old_p"]

        self.base_optimizer.step()  # Update at original point with SAM gradient

        if zero_grad:
            self.zero_grad()

    @torch.no_grad()
    def step(self, closure=None):
        assert closure is not None, "SAM requires closure, but it was not provided"
        closure = torch.enable_grad()(closure)

        # First forward-backward pass
        self.first_step(zero_grad=True)

        # Second forward-backward pass
        closure()
        self.second_step()

    def _grad_norm(self):
        shared_device = self.param_groups[0]["params"][0].device
        norm = torch.norm(
            torch.stack([
                ((torch.abs(p) if group["adaptive"] else 1.0) * p.grad).norm(p=2).to(shared_device)
                for group in self.param_groups for p in group["params"]
                if p.grad is not None
            ]),
            p=2
        )
        return norm


class FTSAMDefense:
    """Fine-Tuning with SAM defense against backdoor attacks."""

    def __init__(self, finetune_epochs=10, lr=0.01, rho=0.05):
        self.finetune_epochs = finetune_epochs
        self.lr = lr
        self.rho = rho
        self.name = "FT-SAM"

    def apply(self, model, clean_dataloader, device, num_classes=10):
        """Apply FT-SAM defense."""
        model.train()

        base_optimizer = torch.optim.SGD
        optimizer = SAM(
            model.parameters(),
            base_optimizer,
            rho=self.rho,
            adaptive=True,
            lr=self.lr,
            momentum=0.9,
            weight_decay=5e-4,
        )
        criterion = nn.CrossEntropyLoss()

        for epoch in range(self.finetune_epochs):
            total_loss = 0
            correct = 0
            total = 0

            for data, target in clean_dataloader:
                data, target = data.to(device), target.to(device)

                def closure():
                    optimizer.zero_grad()
                    output = model(data)
                    loss = criterion(output, target)
                    loss.backward()
                    return loss

                loss = closure()
                optimizer.step(closure)

                total_loss += loss.item()
                _, predicted = model(data).max(1)
                total += target.size(0)
                correct += predicted.eq(target).sum().item()

        return model
