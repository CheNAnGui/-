"""
Core training engine for backdoor attack/defense experiments.
Handles: model training, attack injection, defense application,
evaluation, and automatic visualization saving.
"""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import time
import os
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm
from sklearn.metrics import confusion_matrix

from backend.models import get_model
from backend.datasets import get_dataset
from backend.attacks import get_attack
from backend.defenses import get_defense
from backend.db.database import db
from backend.utils.visualizer import ExperimentVisualizer


class ExperimentTrainer:
    """Main experiment orchestrator with auto-visualization."""

    def __init__(self, exp_id: str, config: dict, device: str = None):
        self.exp_id = exp_id
        self.config = config
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        self.poisoned_test_data = None

        # Directories
        self.results_dir = os.path.join("results", exp_id)
        self.output_dir = os.path.join(self.results_dir, "output")
        os.makedirs(self.output_dir, exist_ok=True)

        # Visualizer
        self.viz = None
        self.sample_images_clean = []
        self.sample_images_poisoned = []

    def log(self, message: str):
        db.append_log(self.exp_id, message)

    def train(self):
        """Run the complete experiment pipeline with auto-save."""
        start_time = time.time()

        try:
            # ===== Step 1: Load dataset =====
            self.log("Loading dataset...")
            db.update_status(self.exp_id, "running", 5)

            dataset_name = self.config["dataset"]
            train_dataset, num_classes, input_channels, classes = get_dataset(
                dataset_name, train=True
            )
            test_dataset, _, _, _ = get_dataset(dataset_name, train=False)

            # Init visualizer
            self.viz = ExperimentVisualizer(self.output_dir, dataset_name)

            # Optional: limit dataset for quick testing
            max_samples = self.config.get("max_samples", None)
            if max_samples and len(train_dataset) > max_samples:
                indices = np.random.choice(len(train_dataset), max_samples, replace=False)
                train_dataset = torch.utils.data.Subset(train_dataset, indices)
                self.log(f"Using subset of {max_samples} training samples")

            # ===== Step 2: Apply backdoor attack =====
            attack_name = self.config["attack"]
            poison_ratio = self.config["poison_ratio"] / 100.0
            target_label = self.config["target_label"]

            self.log(
                f"Applying {attack_name} attack (poison ratio: {poison_ratio * 100:.0f}%)"
            )
            db.update_status(self.exp_id, "running", 10)

            attack_cls = get_attack(attack_name)
            attack = attack_cls()

            poisoned_train_data, poison_indices = attack.poison_dataset(
                train_dataset, poison_ratio, target_label
            )
            self.log(
                f"Poisoned {len(poison_indices)} / {len(train_dataset)} training samples"
            )

            # Create poisoned test set
            poisoned_test = []
            test_len = min(1000, len(test_dataset))
            for idx in range(test_len):
                img, lbl = test_dataset[idx]
                triggered_img = attack.inject_trigger(img)
                poisoned_test.append((triggered_img, target_label))
            self.poisoned_test_data = poisoned_test

            # ===== Save: trigger pattern =====
            trigger_save = self.viz.plot_trigger_pattern(
                attack.get_trigger_pattern(train_dataset[0][0].shape),
                attack_name,
                save_name="01_trigger_pattern.png",
            )
            if trigger_save:
                self.log(f"Saved trigger pattern: {trigger_save}")

            # ===== Collect sample images for comparison =====
            for i in range(min(8, len(test_dataset))):
                clean_img = test_dataset[i][0]
                poison_img = attack.inject_trigger(clean_img)
                self.sample_images_clean.append(clean_img)
                self.sample_images_poisoned.append(poison_img)

            # ===== Save: sample comparison =====
            sample_save = self.viz.plot_sample_comparison(
                self.sample_images_clean,
                self.sample_images_poisoned,
                attack_name,
                target_label,
                save_name="02_sample_comparison.png",
            )
            if sample_save:
                self.log(f"Saved sample comparison: {sample_save}")

            # ===== Step 3: Build model & dataloaders =====
            self.log("Building model...")
            db.update_status(self.exp_id, "running", 15)

            model_name = self.config["model"]
            self.model = get_model(model_name, num_classes=num_classes)
            if input_channels == 1:
                self._adjust_for_grayscale()
            self.model = self.model.to(self.device)

            batch_size = self.config.get("batch_size", 128)

            poisoned_imgs = torch.stack([x[0] for x in poisoned_train_data])
            poisoned_lbls = torch.tensor([x[1] for x in poisoned_train_data])
            train_loader = DataLoader(
                TensorDataset(poisoned_imgs, poisoned_lbls),
                batch_size=batch_size,
                shuffle=True,
                num_workers=0,
                pin_memory=True,
            )

            test_imgs = torch.stack([test_dataset[i][0] for i in range(len(test_dataset))])
            test_lbls = torch.tensor([test_dataset[i][1] for i in range(len(test_dataset))])
            test_loader = DataLoader(
                TensorDataset(test_imgs, test_lbls),
                batch_size=batch_size,
                shuffle=False,
                num_workers=0,
            )

            poison_test_imgs = torch.stack([x[0] for x in poisoned_test])
            poison_test_lbls = torch.tensor([x[1] for x in poisoned_test])
            poison_test_loader = DataLoader(
                TensorDataset(poison_test_imgs, poison_test_lbls),
                batch_size=batch_size,
                shuffle=False,
                num_workers=0,
            )

            # ===== Step 4: Training =====
            self.log(f"Training on {self.device.upper()}...")
            epochs = self.config.get("epochs", 10)
            lr = self.config.get("learning_rate", 0.1)
            optimizer = optim.SGD(
                self.model.parameters(), lr=lr, momentum=0.9, weight_decay=5e-4
            )
            scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
            criterion = nn.CrossEntropyLoss()

            history = {"epochs": [], "cleanAcc": [], "attackSuccessRate": []}

            for epoch in range(epochs):
                self.model.train()
                train_loss = 0
                correct = 0
                total = 0

                pbar = tqdm(train_loader, desc=f"Epoch {epoch + 1}/{epochs}", leave=False)
                for batch_idx, (data, target) in enumerate(pbar):
                    data, target = data.to(self.device), target.to(self.device)
                    optimizer.zero_grad()
                    output = self.model(data)
                    loss = criterion(output, target)
                    loss.backward()
                    optimizer.step()

                    train_loss += loss.item()
                    _, predicted = output.max(1)
                    total += target.size(0)
                    correct += predicted.eq(target).sum().item()
                    pbar.set_postfix(
                        {
                            "loss": f"{train_loss / (batch_idx + 1):.3f}",
                            "acc": f"{100. * correct / total:.1f}%",
                        }
                    )

                scheduler.step()

                # Periodic evaluation
                eval_every = max(1, epochs // 10)  # ~10 evaluation points
                if (epoch + 1) % eval_every == 0 or epoch == epochs - 1:
                    clean_acc = self._evaluate(test_loader)
                    asr = self._evaluate_asr(poison_test_loader)

                    history["epochs"].append(epoch + 1)
                    history["cleanAcc"].append(clean_acc)
                    history["attackSuccessRate"].append(asr)

                    self.log(
                        f"Epoch {epoch + 1}: Clean Acc={clean_acc:.2f}%, ASR={asr:.2f}%"
                    )
                    db.update_status(
                        self.exp_id,
                        "running",
                        15 + int(70 * (epoch + 1) / epochs),
                    )

                    # ===== Save: intermediate convergence curve =====
                    if len(history["epochs"]) >= 2:
                        self.viz.plot_convergence(
                            history,
                            attack_name,
                            self.config["defense"],
                            save_name="03_convergence_curve.png",
                        )

            # ===== Step 5: Defense (if specified) =====
            defense_name = self.config["defense"]
            if defense_name != "None":
                self.log(f"Applying {defense_name} defense...")
                db.update_status(self.exp_id, "running", 90)

                clean_size = min(1000, len(test_dataset))
                clean_indices = np.random.choice(
                    len(test_dataset), clean_size, replace=False
                )
                clean_imgs = torch.stack([test_dataset[i][0] for i in clean_indices])
                clean_lbls = torch.tensor([test_dataset[i][1] for i in clean_indices])
                clean_loader = DataLoader(
                    TensorDataset(clean_imgs, clean_lbls),
                    batch_size=64,
                    shuffle=True,
                    num_workers=0,
                )

                defense_cls = get_defense(defense_name)
                defense = defense_cls()
                self.model = defense.apply(self.model, clean_loader, self.device, num_classes)

                clean_acc = self._evaluate(test_loader)
                asr = self._evaluate_asr(poison_test_loader)
                self.log(
                    f"After {defense_name}: Clean Acc={clean_acc:.2f}%, ASR={asr:.2f}%"
                )

            # ===== Step 6: Final evaluation =====
            self.log("Running final evaluation...")
            db.update_status(self.exp_id, "running", 95)

            final_clean_acc = self._evaluate(test_loader)
            final_asr = self._evaluate_asr(poison_test_loader)
            defense_acc = final_clean_acc if defense_name != "None" else 0

            # Confusion matrix
            cm = self._get_confusion_matrix(test_loader, num_classes)

            # ===== Save: final convergence curve =====
            curve_save = self.viz.plot_convergence(
                history,
                attack_name,
                defense_name,
                save_name="03_convergence_curve.png",
            )
            if curve_save:
                self.log(f"Saved convergence curve: {curve_save}")

            # ===== Save: confusion matrix =====
            cm_save = self.viz.plot_confusion_matrix(
                cm, save_name="04_confusion_matrix.png"
            )
            if cm_save:
                self.log(f"Saved confusion matrix: {cm_save}")

            # ===== Save: defense comparison (if defense applied) =====
            if defense_name != "None":
                defense_results = [
                    {"defense": "Baseline (No Defense)", "clean_acc": history["cleanAcc"][0] if history["cleanAcc"] else 0, "asr": history["attackSuccessRate"][0] if history["attackSuccessRate"] else 0},
                    {"defense": defense_name, "clean_acc": final_clean_acc, "asr": final_asr},
                ]
                comp_save = self.viz.plot_defense_comparison(
                    defense_results, save_name="05_defense_comparison.png"
                )
                if comp_save:
                    self.log(f"Saved defense comparison: {comp_save}")

            # ===== Save model =====
            model_path = os.path.join(self.results_dir, "model.pth")
            torch.save(self.model.state_dict(), model_path)

            time_cost = time.time() - start_time

            # ===== Collect all output files =====
            output_files = self.viz.get_all_saved_files()
            output_paths = {
                "output_dir": self.output_dir,
                "files": output_files,
            }

            # ===== Store results to DB =====
            metrics = {
                "cleanAcc": round(final_clean_acc, 2),
                "attackSuccessRate": round(final_asr, 2),
                "defenseAcc": round(defense_acc, 2),
                "timeCost": round(time_cost, 1),
            }
            db.update_metrics(self.exp_id, metrics)
            db.update_results(self.exp_id, cm.tolist(), history, output_paths)
            db.update_status(self.exp_id, "completed", 100)

            # Log summary
            self.log("=" * 50)
            self.log(f"Experiment {self.exp_id} COMPLETE")
            self.log(f"Clean Accuracy: {final_clean_acc:.2f}%")
            self.log(f"Attack Success Rate: {final_asr:.2f}%")
            self.log(f"Time Cost: {time_cost:.1f}s")
            self.log(f"Output files saved to: {self.output_dir}")
            self.log(f"Files: {', '.join(output_files)}")
            self.log("=" * 50)

            return metrics

        except Exception as e:
            db.update_status(self.exp_id, "failed", 0)
            self.log(f"ERROR: {str(e)}")
            import traceback

            self.log(traceback.format_exc())
            raise

    # ==================== Private methods ====================

    def _evaluate(self, dataloader):
        self.model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for data, target in dataloader:
                data, target = data.to(self.device), target.to(self.device)
                output = self.model(data)
                _, predicted = output.max(1)
                total += target.size(0)
                correct += predicted.eq(target).sum().item()
        return 100.0 * correct / total if total > 0 else 0

    def _evaluate_asr(self, dataloader):
        self.model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for data, target in dataloader:
                data, target = data.to(self.device), target.to(self.device)
                output = self.model(data)
                _, predicted = output.max(1)
                total += target.size(0)
                correct += predicted.eq(target).sum().item()
        return 100.0 * correct / total if total > 0 else 0

    def _get_confusion_matrix(self, dataloader, num_classes):
        self.model.eval()
        all_preds, all_targets = [], []
        with torch.no_grad():
            for data, target in dataloader:
                data = data.to(self.device)
                output = self.model(data)
                _, predicted = output.max(1)
                all_preds.extend(predicted.cpu().numpy())
                all_targets.extend(target.numpy())
        return confusion_matrix(all_targets, all_preds, labels=list(range(num_classes)))

    def _adjust_for_grayscale(self):
        for name, module in self.model.named_modules():
            if isinstance(module, nn.Conv2d) and name == "conv1":
                new_conv = nn.Conv2d(
                    1,
                    module.out_channels,
                    kernel_size=module.kernel_size,
                    stride=module.stride,
                    padding=module.padding,
                    bias=False,
                )
                parent = self._get_parent_module(name)
                setattr(parent, name.split(".")[-1], new_conv)
                break

    def _get_parent_module(self, module_name):
        parts = module_name.split(".")
        module = self.model
        for part in parts[:-1]:
            module = getattr(module, part)
        return module
