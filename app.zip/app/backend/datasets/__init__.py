import torch
from torchvision import datasets, transforms


def get_dataset(name: str, train: bool = True, data_root: str = "./data"):
    """Load a dataset by name."""
    if name == "MNIST":
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,)),
        ])
        dataset = datasets.MNIST(
            root=data_root, train=train, download=True, transform=transform
        )
        num_classes = 10
        input_channels = 1
        classes = [str(i) for i in range(10)]

    elif name == "CIFAR-10":
        if train:
            transform = transforms.Compose([
                transforms.RandomCrop(32, padding=4),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
            ])
        else:
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
            ])
        dataset = datasets.CIFAR10(
            root=data_root, train=train, download=True, transform=transform
        )
        num_classes = 10
        input_channels = 3
        classes = ["Airplane", "Automobile", "Bird", "Cat", "Deer",
                     "Dog", "Frog", "Horse", "Ship", "Truck"]

    elif name == "GTSRB":
        split = "train" if train else "test"
        transform = transforms.Compose([
            transforms.Resize((32, 32)),
            transforms.ToTensor(),
            transforms.Normalize((0.3337, 0.3064, 0.3171), (0.2672, 0.2564, 0.2629)),
        ])
        dataset = datasets.GTSRB(
            root=data_root, split=split, download=True, transform=transform
        )
        num_classes = 43
        input_channels = 3
        classes = [f"Class_{i}" for i in range(43)]

    else:
        raise ValueError(f"Unknown dataset: {name}")

    return dataset, num_classes, input_channels, classes
