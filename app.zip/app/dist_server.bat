@echo off
chcp 65001 >nul
title Backdoor Defense Lab - Frontend
echo ============================================
echo   Backdoor Defense Lab - Frontend Server
echo ============================================
echo.
echo Serving dist/ folder at http://localhost:3000
echo.
echo If Python is not available, you can directly
echo open dist/index.html in your browser.
echo.

cd /d "%~dp0dist"
python -m http.server 3000

pause
