# Backdoor Defense Lab
## ML Backdoor Attack & Defense Experiment Platform

A professional-grade, full-stack web application for conducting and visualizing machine learning backdoor attack and defense experiments. Designed for educational and research purposes in network and information security courses.

![Architecture](https://img.shields.io/badge/Stack-FastAPI%20%2B%20React%20%2B%20PyTorch-blue)
![GPU](https://img.shields.io/badge/GPU-RTX%204060%20Ready-green)
![Python](https://img.shields.io/badge/Python-3.10%2B-blue)

---

## Features

### 5 Backdoor Attack Methods
| Attack | Type | Description |
|--------|------|-------------|
| **BadNets** | Visible | 3x3 white square patch at corner |
| **Blended** | Invisible | Pattern blended at alpha=0.2 |
| **WaNet** | Invisible | Spatial warping (imperceptible) |
| **SIG** | Invisible | Sinusoidal signal injection |
| **LF** | Invisible | Low-frequency DCT trigger |

### 3 Defense Methods
| Defense | Type | Description |
|---------|------|-------------|
| **Fine-Pruning** | Elimination | Prune inactive neurons + fine-tune |
| **FT-SAM** | Elimination | Sharpness-Aware Minimization |
| **STRIP** | Detection | Entropy-based input detection |

### Datasets
- **MNIST**: 60K train / 10K test, 10 classes
- **CIFAR-10**: 50K train / 10K test, 10 classes
- **GTSRB**: 39K train / 12K test, 43 classes (traffic signs)

### Models
- ResNet-18 (11M parameters)
- VGG-16 (15M parameters)
- PreAct-ResNet (11M parameters)

### Visualizations
- Real-time neural activation flow (Canvas particle system)
- Confusion matrix heatmap with hover tooltips
- Clean vs poisoned sample comparison
- Training convergence curves (ACC vs ASR)
- Real-time execution log terminal

---

## Quick Start

### Prerequisites
- Python 3.10+
- Node.js 20+
- CUDA-capable GPU (RTX 4060 8GB Laptop recommended)
- 16GB+ system RAM

### Installation

```bash
# 1. Clone/navigate to the project directory
cd backdoor-defense-lab

# 2. Install Python dependencies
pip install -r backend/requirements.txt

# 3. Install frontend dependencies (if developing)
npm install
```

### Running the Application

**Option 1: Full Stack (Recommended)**
```bash
# Terminal 1: Start Python backend
python backend/scripts/run_server.py --port 8000

# Terminal 2: Start frontend dev server
npm run dev
```

Then open http://localhost:3000 in your browser.

**Option 2: Frontend Only (Demo Mode)**
```bash
npm run dev
```
The frontend includes a built-in simulation mode that demonstrates all visualizations without requiring the backend.

**Option 3: Backend API Only**
```bash
python backend/scripts/run_server.py --host 0.0.0.0 --port 8000
```
API docs available at http://localhost:8000/docs

---

## Experiment Guide

### Recommended Experiment Schedule (RTX 4060 Laptop)

Each experiment takes 30-120 minutes depending on dataset and epochs.

**Session 1 (2-3 hours): Baseline Attacks**
1. CIFAR-10 + ResNet-18 + BadNets + None (poison: 10%)
2. CIFAR-10 + ResNet-18 + Blended + None (poison: 10%)
3. CIFAR-10 + ResNet-18 + WaNet + None (poison: 10%)

**Session 2 (2-3 hours): Defense Evaluation**
4. CIFAR-10 + ResNet-18 + BadNets + Fine-Pruning (poison: 10%)
5. CIFAR-10 + ResNet-18 + BadNets + FT-SAM (poison: 10%)
6. CIFAR-10 + ResNet-18 + BadNets + STRIP (poison: 10%)

**Session 3 (2-3 hours): Cross-Validation**
7. CIFAR-10 + ResNet-18 + SIG + Fine-Pruning (poison: 5%)
8. MNIST + ResNet-18 + BadNets + FT-SAM (poison: 10%)
9. GTSRB + ResNet-18 + Blended + Fine-Pruning (poison: 10%)

**Session 4 (2-3 hours): Advanced Study**
10-15. Vary poison ratios (1%, 5%, 10%, 20%) with best attack+defense combo

### GPU Memory Optimization
- Batch Size 128 for CIFAR-10/MNIST
- Batch Size 64 for GTSRB (43 classes)
- Reduce epochs to 30 for quick validation
- Use `max_samples` limit for initial testing

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/gpu-info` | GPU information |
| GET | `/api/datasets` | Available datasets |
| GET | `/api/models` | Available models |
| GET | `/api/attacks` | Available attacks |
| GET | `/api/defenses` | Available defenses |
| POST | `/api/experiments` | Create & start experiment |
| GET | `/api/experiments` | List experiments |
| GET | `/api/experiments/{id}` | Get experiment status |
| GET | `/api/experiments/{id}/logs` | Get experiment logs |
| DELETE | `/api/experiments/{id}` | Delete experiment |

---

## Project Structure

```
backdoor-defense-lab/
├── backend/                    # Python FastAPI + PyTorch backend
│   ├── main.py                # FastAPI application
│   ├── requirements.txt       # Python dependencies
│   ├── models/                # PyTorch model architectures
│   │   ├── resnet.py         # ResNet-18, PreAct-ResNet
│   │   └── vgg.py            # VGG-16
│   ├── attacks/               # Backdoor attack implementations
│   │   ├── badnets.py        # BadNets corner patch
│   │   ├── blended.py        # Blended pattern
│   │   ├── wanet.py          # WaNet spatial warping
│   │   ├── sig.py            # SIG sinusoidal
│   │   └── lf.py             # LF low-frequency DCT
│   ├── defenses/              # Defense implementations
│   │   ├── fine_pruning.py   # Fine-Pruning
│   │   ├── ft_sam.py         # FT-SAM optimizer
│   │   └── strip.py          # STRIP detection
│   ├── datasets/              # Dataset loaders
│   ├── training/              # Training engine
│   │   └── trainer.py        # Experiment orchestrator
│   ├── db/                    # SQLite database
│   │   └── database.py       # Experiment persistence
│   └── scripts/
│       └── run_server.py     # Server launch script
├── src/                       # React frontend
│   ├── App.tsx               # Main layout
│   ├── types/                # TypeScript types
│   ├── components/           # React components
│   │   ├── Sidebar.tsx       # Parameter control panel
│   │   ├── DataFlowCanvas.tsx # Particle animation
│   │   ├── MetricsCards.tsx   # KPI display
│   │   ├── ConfusionMatrix.tsx # Heatmap visualization
│   │   ├── SampleComparison.tsx # Clean vs poisoned
│   │   ├── TrainingCurves.tsx  # Convergence plots
│   │   └── ExperimentLog.tsx   # Terminal output
│   └── index.css             # Academic theme styles
├── dist/                      # Production build
├── package.json              # Node.js dependencies
├── vite.config.ts            # Vite configuration
├── tailwind.config.js        # Tailwind theme
└── README.md                 # This file
```

---

## Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| GPU | 4GB VRAM | RTX 4060 8GB |
| RAM | 8GB | 16GB |
| Storage | 10GB | 20GB |
| OS | Linux/Windows | Ubuntu 22.04 |

---

## Citation

If you use this platform for your coursework or research:
```bibtex
@software{backdoor_defense_lab,
  title={Backdoor Defense Lab: ML Security Benchmark Platform},
  author={Security Lab},
  year={2025},
  note={Educational tool for backdoor attack and defense experiments}
}
```

---

## License

This project is provided for educational and research purposes only.
