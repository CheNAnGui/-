export interface ExperimentConfig {
  dataset: "MNIST" | "CIFAR-10" | "GTSRB";
  model: "ResNet-18" | "VGG-16" | "PreAct-ResNet";
  attack: "BadNets" | "Blended" | "WaNet" | "SIG" | "LF";
  defense: "None" | "Fine-Pruning" | "NAD" | "FT-SAM" | "STRIP";
  poisonRatio: number;
  epochs: number;
  batchSize: number;
  learningRate: number;
  targetLabel: number;
}

export interface ExperimentMetrics {
  cleanAcc: number;
  attackSuccessRate: number;
  defenseAcc: number;
  timeCost: number;
}

export interface TrainingHistory {
  epochs: number[];
  cleanAcc: number[];
  attackSuccessRate: number[];
}

export interface ExperimentSamples {
  clean: string[];
  poisoned: string[];
}

export type ExperimentStatus = "idle" | "running" | "completed" | "failed";

export interface Experiment {
  id: string;
  config: ExperimentConfig;
  status: ExperimentStatus;
  progress: number;
  metrics: ExperimentMetrics;
  confusionMatrix: number[][];
  trainingHistory: TrainingHistory;
  samples: ExperimentSamples;
}

export const defaultExperimentConfig: ExperimentConfig = {
  dataset: "CIFAR-10",
  model: "ResNet-18",
  attack: "BadNets",
  defense: "None",
  poisonRatio: 10,
  epochs: 50,
  batchSize: 128,
  learningRate: 0.1,
  targetLabel: 0,
};

export const DATASET_OPTIONS: ExperimentConfig["dataset"][] = ["MNIST", "CIFAR-10", "GTSRB"];
export const MODEL_OPTIONS: ExperimentConfig["model"][] = ["ResNet-18", "VGG-16", "PreAct-ResNet"];
export const ATTACK_OPTIONS: ExperimentConfig["attack"][] = ["BadNets", "Blended", "WaNet", "SIG", "LF"];
export const DEFENSE_OPTIONS: ExperimentConfig["defense"][] = ["None", "Fine-Pruning", "NAD", "FT-SAM", "STRIP"];

export const ATTACK_DESCRIPTIONS: Record<string, string> = {
  BadNets: "Corner patch trigger (3x3 white square)",
  Blended: "Blended pattern trigger (alpha=0.2)",
  WaNet: "Spatial warping trigger (imperceptible)",
  SIG: "Sinusoidal signal trigger",
  LF: "Low-frequency DCT trigger",
};

export const DEFENSE_DESCRIPTIONS: Record<string, string> = {
  None: "No defense (baseline attack)",
  "Fine-Pruning": "Prune inactive neurons + fine-tune",
  NAD: "Neural Attention Distillation",
  "FT-SAM": "Fine-Tuning with Sharpness-Aware Minimization",
  STRIP: "Entropy-based input detection",
};
