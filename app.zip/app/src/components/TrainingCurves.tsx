import type { TrainingHistory } from "@/types/experiment";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface TrainingCurvesProps {
  history: TrainingHistory;
}

interface ChartDataPoint {
  epoch: number;
  cleanAcc: number;
  attackSuccessRate: number;
}

export function TrainingCurves({ history }: TrainingCurvesProps) {
  if (!history.epochs.length) {
    return (
      <div className="h-64 flex items-center justify-center text-sm text-[#6c757d]">
        No training data available
      </div>
    );
  }

  const data: ChartDataPoint[] = history.epochs.map((epoch, i) => ({
    epoch,
    cleanAcc: Math.min(100, Math.max(0, history.cleanAcc[i] || 0)),
    attackSuccessRate: Math.min(100, Math.max(0, history.attackSuccessRate[i] || 0)),
  }));

  return (
    <ResponsiveContainer width="100%" height={256}>
      <LineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e8edf3" />
        <XAxis
          dataKey="epoch"
          tick={{ fontSize: 10, fill: "#6c757d" }}
          axisLine={{ stroke: "#e0e0e0" }}
          tickLine={{ stroke: "#e0e0e0" }}
          label={{ value: "Epoch", position: "insideBottom", offset: -2, style: { fontSize: 10, fill: "#6c757d" } }}
        />
        <YAxis
          domain={[0, 100]}
          tick={{ fontSize: 10, fill: "#6c757d" }}
          axisLine={{ stroke: "#e0e0e0" }}
          tickLine={{ stroke: "#e0e0e0" }}
          label={{ value: "Accuracy (%)", angle: -90, position: "insideLeft", offset: 10, style: { fontSize: 10, fill: "#6c757d" } }}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: "#0b1d3a",
            border: "none",
            borderRadius: "0",
            fontSize: "11px",
            color: "#fff",
            padding: "8px 12px",
          }}
          itemStyle={{ fontSize: "11px" }}
          formatter={(value: number) => [`${value.toFixed(2)}%`, ""]}
          labelFormatter={(label: number) => `Epoch ${label}`}
        />
        <Legend
          wrapperStyle={{ fontSize: "11px" }}
          iconType="line"
        />
        <Line
          type="monotone"
          dataKey="cleanAcc"
          name="Clean Accuracy"
          stroke="#0b1d3a"
          strokeWidth={2}
          dot={false}
          activeDot={{ r: 4, fill: "#0b1d3a" }}
        />
        <Line
          type="monotone"
          dataKey="attackSuccessRate"
          name="Attack Success Rate"
          stroke="#e6a532"
          strokeWidth={2}
          dot={false}
          activeDot={{ r: 4, fill: "#e6a532" }}
          strokeDasharray={history.attackSuccessRate[history.attackSuccessRate.length - 1] < 20 ? "5 3" : "0"}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
