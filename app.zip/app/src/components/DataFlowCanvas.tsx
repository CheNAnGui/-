import { useRef, useEffect, useCallback } from "react";

interface DataFlowCanvasProps {
  isRunning: boolean;
  attackType: string;
}

interface Particle {
  x: number;
  y: number;
  tx: number;
  ty: number;
  speed: number;
  progress: number;
}

export function DataFlowCanvas({ isRunning, attackType }: DataFlowCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const rafRef = useRef<number>(0);
  const mouseRef = useRef<{ x: number; y: number } | null>(null);

  const initParticles = useCallback((canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;
    canvas.width = width;
    canvas.height = height;

    const step = 60;
    const w = Math.ceil(width / step);
    const h = Math.ceil(height / step);
    const cx = w * step;
    const cy = h * step;

    const nodes: [number, number][] = [];
    for (let i = 0; i <= w; i++) {
      for (let j = 0; j <= h; j++) {
        nodes.push([i * step - cx / 2, j * step - cy / 2]);
      }
    }

    const to = (p: [number, number]) => ({
      x: p[0] + cx / 2,
      y: p[1] + cy / 2,
    });

    particlesRef.current = [];

    const run = (time: number) => {
      if (!canvasRef.current) return;
      const c = canvasRef.current.getContext("2d");
      if (!c) return;

      c.fillStyle = "#ffffff";
      c.fillRect(0, 0, width, height);

      const particles = particlesRef.current;
      const speedMultiplier = isRunning ? 3 : 1;

      for (let idx = 0; idx < nodes.length; idx++) {
        const pt = nodes[idx];
        const idy = idx % (h + 1);
        
        let dx = pt[0];
        let dy = pt[1];
        
        // Mouse interaction
        if (mouseRef.current) {
          const mx = mouseRef.current.x - cx / 2;
          const my = mouseRef.current.y - cy / 2;
          dx -= mx * 0.3;
          dy -= my * 0.3;
        }
        
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const t = Math.sin(dist / 50 - time / 500) * 2;
        const pos = to([pt[0] + (dx / dist) * t, pt[1] + (dy / dist) * t]);

        // Draw connections to neighbors
        const neighbors = [[1, 0], [0, 1]];
        for (const n of neighbors) {
          const ni = idx + n[0] * (h + 1) + n[1];
          const nj = idy + n[1];
          
          if (ni < 0 || ni >= nodes.length || nj > h) continue;
          
          const np = nodes[ni];
          let ndx = np[0];
          let ndy = np[1];
          
          if (mouseRef.current) {
            const mx = mouseRef.current.x - cx / 2;
            const my = mouseRef.current.y - cy / 2;
            ndx -= mx * 0.3;
            ndy -= my * 0.3;
          }
          
          const ndist = Math.sqrt(ndx * ndx + ndy * ndy) || 1;
          const nt = Math.sin(ndist / 50 - time / 500) * 2;
          const npos = to([np[0] + (ndx / ndist) * nt, np[1] + (ndy / ndist) * nt]);

          const opa = Math.max(0, 1 - dist / 400) * 0.35;
          const g = c.createLinearGradient(pos.x, pos.y, npos.x, npos.y);
          
          // Attack-specific color tint
          if (attackType === "BadNets") {
            g.addColorStop(0, `rgba(230, 165, 50, ${opa})`);
            g.addColorStop(1, `rgba(255, 255, 255, ${opa})`);
          } else if (attackType === "Blended") {
            g.addColorStop(0, `rgba(76, 175, 80, ${opa})`);
            g.addColorStop(1, `rgba(255, 255, 255, ${opa})`);
          } else {
            g.addColorStop(0, `rgba(58, 90, 138, ${opa})`);
            g.addColorStop(1, `rgba(255, 255, 255, ${opa})`);
          }
          
          c.strokeStyle = g;
          c.lineWidth = 1;
          c.beginPath();
          c.moveTo(pos.x, pos.y);
          c.lineTo(npos.x, npos.y);
          c.stroke();

          // Spawn particles
          if (dist > 0 && Math.random() < 0.02 * speedMultiplier) {
            particles.push({
              x: pos.x,
              y: pos.y,
              tx: npos.x,
              ty: npos.y,
              speed: (1 + Math.random() * 2) * speedMultiplier,
              progress: 0,
            });
          }
        }
      }

      // Update and draw particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.progress += 0.01 * p.speed;
        const px = p.x + (p.tx - p.x) * p.progress;
        const py = p.y + (p.ty - p.y) * p.progress;

        // Particle color based on attack type
        if (attackType === "BadNets") {
          c.fillStyle = "#e6a532";
        } else if (attackType === "Blended") {
          c.fillStyle = "#4caf50";
        } else if (attackType === "WaNet") {
          c.fillStyle = "#e57373";
        } else {
          c.fillStyle = "#3a5a8a";
        }
        
        c.beginPath();
        c.arc(px, py, isRunning ? 2.5 : 1.8, 0, Math.PI * 2);
        c.fill();

        if (p.progress >= 1) {
          particles.splice(i, 1);
        }
      }

      rafRef.current = requestAnimationFrame(run);
    };

    rafRef.current = requestAnimationFrame(run);
  }, [isRunning, attackType]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    initParticles(canvas);

    const handleResize = () => {
      cancelAnimationFrame(rafRef.current);
      initParticles(canvas);
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    };

    const handleMouseLeave = () => {
      mouseRef.current = null;
    };

    window.addEventListener("resize", handleResize);
    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseleave", handleMouseLeave);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", handleResize);
      canvas.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, [initParticles]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ display: "block" }}
    />
  );
}
