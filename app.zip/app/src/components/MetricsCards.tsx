import type { Experiment } from "@/types/experiment";
import { Target, Crosshair, Shield, Clock } from "lucide-react";

interface MetricsCardsProps {
  experiment: Experiment | null;
}

export function MetricsCards({ experiment }: MetricsCardsProps) {
  const metrics = experiment?.metrics;
  const isRunning = experiment?.status === "running";

  const cards = [
    {
      label: "Clean Accuracy",
      value: metrics ? `${metrics.cleanAcc.toFixed(2)}%` : "--",
      icon: Target,
      color: "#0b1d3a",
      bgColor: "#e8edf3",
    },
    {
      label: "Attack Success Rate",
      value: metrics ? `${metrics.attackSuccessRate.toFixed(2)}%` : "--",
      icon: Crosshair,
      color: "#e6a532",
      bgColor: "#fdf5e0",
    },
    {
      label: "Defense Accuracy",
      value: metrics ? `${metrics.defenseAcc.toFixed(2)}%` : "--",
      icon: Shield,
      color: "#4caf50",
      bgColor: "#e8f5e9",
    },
    {
      label: "Time Cost",
      value: metrics && metrics.timeCost > 0 ? `${metrics.timeCost.toFixed(1)}s` : "--",
      icon: Clock,
      color: "#6c757d",
      bgColor: "#f0f0f0",
    },
  ];

  return (
    <div className="grid grid-cols-4 gap-0 border-b border-[#e0e0e0]">
      {cards.map((card, i) => (
        <div
          key={i}
          className={`px-5 py-3.5 flex items-center gap-3 ${
            i < cards.length - 1 ? "border-r border-[#e0e0e0]" : ""
          }`}
        >
          <div
            className="w-9 h-9 flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: card.bgColor }}
          >
            <card.icon className="w-4.5 h-4.5" style={{ color: card.color }} />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] font-medium uppercase tracking-wider text-[#6c757d] truncate">
              {card.label}
            </p>
            <p
              className="metric-value text-xl leading-tight mt-0.5"
              style={{ color: card.color }}
            >
              {isRunning && !metrics?.cleanAcc ? (
                <span className="inline-block w-16 h-5 skeleton-shimmer rounded-sm" />
              ) : (
                card.value
              )}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
