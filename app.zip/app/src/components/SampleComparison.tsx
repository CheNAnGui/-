import { useState } from "react";

interface SampleComparisonProps {
  cleanSamples: string[];
  poisonedSamples: string[];
  attackType: string;
}

// Generate placeholder images with different colors/patterns
const SAMPLE_COLORS = [
  ["#4a90d9", "#f0f8ff"], // airplane - sky blue
  ["#d94a4a", "#fff0f0"], // automobile - red
  ["#4ad94a", "#f0fff0"], // bird - green
  ["#d9a04a", "#fff8f0"], // cat - orange
  ["#9a4ad9", "#f8f0ff"], // deer - purple
  ["#4ad9d9", "#f0ffff"], // dog - cyan
  ["#8bd94a", "#f4fff0"], // frog - lime
  ["#d94a8b", "#fff0f5"], // horse - pink
];

function generatePlaceholderSvg(index: number, isPoisoned: boolean, attackType: string): string {
  const [color1, color2] = SAMPLE_COLORS[index % SAMPLE_COLORS.length];
  const size = 32;
  
  // Different trigger patterns based on attack type
  let triggerOverlay = "";
  if (isPoisoned) {
    if (attackType === "BadNets") {
      triggerOverlay = `<rect x="24" y="24" width="8" height="8" fill="white" stroke="black" stroke-width="0.5"/>`;
    } else if (attackType === "Blended") {
      triggerOverlay = `<rect x="0" y="0" width="32" height="32" fill="url(#blend${index})" opacity="0.3"/>`;
    } else if (attackType === "WaNet") {
      triggerOverlay = `<circle cx="16" cy="16" r="12" fill="none" stroke="red" stroke-width="0.5" opacity="0.5"/>`;
    } else if (attackType === "SIG") {
      triggerOverlay = `<path d="M0,16 Q8,8 16,16 T32,16" fill="none" stroke="yellow" stroke-width="1" opacity="0.6"/>`;
    } else {
      triggerOverlay = `<rect x="20" y="20" width="12" height="12" fill="white" opacity="0.4"/>`;
    }
  }

  // Generate simple shape for the class
  const shapes = [
    `<polygon points="16,4 28,28 4,28" fill="${color1}"/>`, // triangle
    `<rect x="6" y="10" width="20" height="14" rx="3" fill="${color1}"/>`, // rectangle
    `<circle cx="16" cy="16" r="10" fill="${color1}"/>`, // circle
    `<polygon points="16,6 22,14 20,24 12,24 10,14" fill="${color1}"/>`, // pentagon
  ];
  const shape = shapes[index % shapes.length];

  const blendPattern = isPoisoned && attackType === "Blended" 
    ? `<defs><pattern id="blend${index}" patternUnits="userSpaceOnUse" width="8" height="8"><circle cx="4" cy="4" r="2" fill="#ff6b6b"/></pattern></defs>`
    : "";

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    ${blendPattern}
    <rect width="${size}" height="${size}" fill="${color2}"/>
    ${shape}
    ${triggerOverlay}
  </svg>`;

  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

export function SampleComparison({ cleanSamples, poisonedSamples, attackType }: SampleComparisonProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const displayCount = Math.min(8, cleanSamples.length, poisonedSamples.length);
  
  const classNames = ["Airplane", "Automobile", "Bird", "Cat", "Deer", "Dog", "Frog", "Horse"];

  return (
    <div className="space-y-4">
      {/* Clean Samples */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="academic-label">Clean Samples (Original)</span>
        </div>
        <div className="flex gap-3 flex-wrap">
          {Array.from({ length: displayCount }, (_, i) => (
            <div
              key={`clean-${i}`}
              className="relative group"
              onMouseEnter={() => setHoveredIndex(i)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              <div className="w-16 h-16 border border-[#e0e0e0] bg-[#fafafa] overflow-hidden">
                <img
                  src={generatePlaceholderSvg(i, false, attackType)}
                  alt={`Clean sample ${i}`}
                  className="w-full h-full object-contain"
                  style={{ imageRendering: "pixelated" }}
                />
              </div>
              <span className="block text-[9px] text-[#6c757d] text-center mt-1 truncate w-16">
                {classNames[i % classNames.length]}
              </span>
              
              {hoveredIndex === i && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-1 bg-[#0b1d3a] text-white text-[10px] whitespace-nowrap z-50 pointer-events-none">
                  Clean: {classNames[i % classNames.length]}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-[4px] border-r-[4px] border-t-[4px] border-l-transparent border-r-transparent border-t-[#0b1d3a]" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Poisoned Samples */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="academic-label flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-[#e6a532] inline-block" />
            Poisoned Samples ({attackType})
          </span>
          <span className="text-[9px] text-[#e6a532] bg-[#fdf5e0] px-2 py-0.5 border border-[#e6a532]/30">
            Target: Class 0
          </span>
        </div>
        <div className="flex gap-3 flex-wrap">
          {Array.from({ length: displayCount }, (_, i) => (
            <div
              key={`poisoned-${i}`}
              className="relative group"
              onMouseEnter={() => setHoveredIndex(100 + i)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              <div className="w-16 h-16 border-2 border-[#e6a532] bg-[#fafafa] overflow-hidden relative">
                <img
                  src={generatePlaceholderSvg(i, true, attackType)}
                  alt={`Poisoned sample ${i}`}
                  className="w-full h-full object-contain"
                  style={{ imageRendering: "pixelated" }}
                />
                {/* Trigger indicator */}
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-white border border-[#e6a532] flex items-center justify-center">
                  <span className="text-[6px] text-[#e6a532]">T</span>
                </div>
              </div>
              <span className="block text-[9px] text-[#e6a532] text-center mt-1 truncate w-16 font-medium">
                → {classNames[0]}
              </span>
              
              {hoveredIndex === 100 + i && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-1 bg-[#0b1d3a] text-white text-[10px] whitespace-nowrap z-50 pointer-events-none">
                  True: {classNames[i % classNames.length]} → Pred: {classNames[0]}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-[4px] border-r-[4px] border-t-[4px] border-l-transparent border-r-transparent border-t-[#0b1d3a]" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Attack trigger explanation */}
      <div className="pt-2 border-t border-[#e0e0e0]">
        <div className="flex items-center gap-2 text-[10px] text-[#6c757d]">
          <span className="w-2 h-2 bg-white border border-[#e6a532]" />
          <span>Trigger region visible in corner (BadNets: 3×3 white patch)</span>
        </div>
      </div>
    </div>
  );
}
