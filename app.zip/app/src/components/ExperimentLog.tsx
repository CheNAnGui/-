import { useRef, useEffect } from "react";
import { Terminal } from "lucide-react";

interface ExperimentLogProps {
  logs: string[];
}

export function ExperimentLog({ logs }: ExperimentLogProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const getLogColor = (log: string): string => {
    if (log.includes("[System]")) return "#6c757d";
    if (log.includes("[Experiment")) return "#0b1d3a";
    if (log.includes("[Config]")) return "#3a5a8a";
    if (log.includes("[Result]")) return "#4caf50";
    if (log.includes("[Log]")) return "#8aacc8";
    return "#1a1a1a";
  };

  const getLogWeight = (log: string): string => {
    if (log.includes("[Result]")) return "600";
    if (log.includes("[Experiment")) return "500";
    return "400";
  };

  return (
    <div className="flex flex-col">
      <div className="flex items-center gap-2 mb-2">
        <Terminal className="w-3.5 h-3.5 text-[#6c757d]" />
        <span className="text-[10px] text-[#6c757d] uppercase tracking-wider">Real-time Output</span>
      </div>
      <div
        ref={scrollRef}
        className="h-32 overflow-y-auto bg-[#0b1d3a] p-3 font-mono text-[11px] leading-relaxed custom-scrollbar"
      >
        {logs.map((log, i) => (
          <div
            key={i}
            className="animate-fade-in"
            style={{ 
              color: getLogColor(log),
              fontWeight: getLogWeight(log),
              animationDelay: `${i * 0.05}s`,
            }}
          >
            {log}
          </div>
        ))}
        {logs.length > 0 && logs[logs.length - 1].includes("running") && (
          <div className="text-[#e6a532] animate-pulse">_</div>
        )}
      </div>
    </div>
  );
}
