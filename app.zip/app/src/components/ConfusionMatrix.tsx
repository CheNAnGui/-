import { useState } from "react";

interface ConfusionMatrixProps {
  matrix: number[][];
  labels: string[];
}

function getHeatmapColor(value: number, maxVal: number): string {
  const v = value / maxVal;
  const r = Math.round(230 + (76 - 230) * v);
  const g = Math.round(230 + (175 - 230) * v);
  const b = Math.round(230 + (80 - 230) * v);
  return `rgb(${r}, ${g}, ${b})`;
}

export function ConfusionMatrix({ matrix, labels }: ConfusionMatrixProps) {
  const [hoveredCell, setHoveredCell] = useState<{ row: number; col: number } | null>(null);
  const maxVal = Math.max(...matrix.flat(), 1);

  return (
    <div className="flex flex-col items-center">
      <div className="flex items-start gap-1">
        {/* Y-axis labels */}
        <div className="flex flex-col justify-around pr-1 pt-6" style={{ height: `${matrix.length * 32 + (matrix.length - 1) * 2}px` }}>
          {labels.map((label, i) => (
            <span key={i} className="text-[9px] text-[#6c757d] text-right leading-[32px] w-12 truncate">
              {label}
            </span>
          ))}
        </div>

        <div>
          {/* X-axis labels */}
          <div className="flex gap-[2px] mb-1 pl-0">
            {labels.map((label, i) => (
              <span key={i} className="text-[9px] text-[#6c757d] text-center w-[32px] truncate rotate-0">
                {label}
              </span>
            ))}
          </div>

          {/* Matrix grid */}
          <div className="flex flex-col gap-[2px]">
            {matrix.map((row, rowIndex) => (
              <div key={rowIndex} className="flex gap-[2px]">
                {row.map((value, colIndex) => {
                  const isHovered = hoveredCell?.row === rowIndex && hoveredCell?.col === colIndex;
                  const isDiagonal = rowIndex === colIndex;
                  return (
                    <div
                      key={colIndex}
                      className="relative flex items-center justify-center cursor-crosshair transition-all duration-100"
                      style={{
                        width: 32,
                        height: 32,
                        backgroundColor: getHeatmapColor(value, maxVal),
                        outline: isHovered ? "2px solid #0b1d3a" : isDiagonal ? "1px solid rgba(255,255,255,0.3)" : "none",
                        outlineOffset: "-1px",
                        zIndex: isHovered ? 10 : 1,
                      }}
                      onMouseEnter={() => setHoveredCell({ row: rowIndex, col: colIndex })}
                      onMouseLeave={() => setHoveredCell(null)}
                    >
                      {isDiagonal && (
                        <span className="text-white text-[10px] font-bold" style={{ textShadow: "0 0 2px rgba(0,0,0,0.5)" }}>
                          {value}
                        </span>
                      )}
                      
                      {/* Tooltip */}
                      {isHovered && (
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2 py-1 bg-[#0b1d3a] text-white text-[10px] whitespace-nowrap z-50 pointer-events-none shadow-lg">
                          True: {labels[rowIndex]} / Pred: {labels[colIndex]}
                          <br />
                          Count: {value}
                          <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-[4px] border-r-[4px] border-t-[4px] border-l-transparent border-r-transparent border-t-[#0b1d3a]" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-2 mt-3">
        <span className="text-[9px] text-[#6c757d]">0</span>
        <div className="w-32 h-2 flex">
          {Array.from({ length: 20 }, (_, i) => (
            <div
              key={i}
              className="flex-1 h-full"
              style={{ backgroundColor: getHeatmapColor(i, 19) }}
            />
          ))}
        </div>
        <span className="text-[9px] text-[#6c757d]">{maxVal}</span>
      </div>
    </div>
  );
}
