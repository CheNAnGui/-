import { useState } from "react";
import { 
  Database, 
  Brain, 
  ShieldAlert, 
  ShieldCheck, 
  Beaker, 
  Percent, 
  Hash, 
  Layers,
  Play,
  Loader2,
  ChevronDown,
  FlaskConical,
  Settings2
} from "lucide-react";
import type { ExperimentConfig } from "@/types/experiment";
import {
  DATASET_OPTIONS,
  MODEL_OPTIONS,
  ATTACK_OPTIONS,
  DEFENSE_OPTIONS,
  ATTACK_DESCRIPTIONS,
  DEFENSE_DESCRIPTIONS,
} from "@/types/experiment";

interface SidebarProps {
  config: ExperimentConfig;
  onConfigChange: (config: Partial<ExperimentConfig>) => void;
  onStartExperiment: () => void;
  isRunning: boolean;
}

export function Sidebar({ config, onConfigChange, onStartExperiment, isRunning }: SidebarProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);

  return (
    <aside className="w-[320px] min-w-[320px] h-full bg-[#0b1d3a] text-white flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-5 pt-6 pb-4 border-b border-[#1a3a5c]">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 bg-[#e6a532] flex items-center justify-center">
            <FlaskConical className="w-5 h-5 text-[#0b1d3a]" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-wide" style={{ fontFamily: 'Merriweather, Georgia, serif' }}>
              Backdoor Defense Lab
            </h1>
            <p className="text-[10px] text-[#8aacc8] uppercase tracking-wider">ML Security Benchmark</p>
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar px-5 py-5 space-y-5">
        {/* Dataset */}
        <div>
          <label className="sidebar-label flex items-center gap-2">
            <Database className="w-3.5 h-3.5" />
            Dataset
          </label>
          <div className="relative">
            <select
              className="sidebar-select appearance-none pr-8"
              value={config.dataset}
              onChange={(e) => onConfigChange({ dataset: e.target.value as ExperimentConfig["dataset"] })}
              disabled={isRunning}
            >
              {DATASET_OPTIONS.map((d) => (
                <option key={d} value={d} className="bg-[#0b1d3a] text-white">{d}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8aacc8] pointer-events-none" />
          </div>
        </div>

        {/* Model Architecture */}
        <div>
          <label className="sidebar-label flex items-center gap-2">
            <Brain className="w-3.5 h-3.5" />
            Model Architecture
          </label>
          <div className="relative">
            <select
              className="sidebar-select appearance-none pr-8"
              value={config.model}
              onChange={(e) => onConfigChange({ model: e.target.value as ExperimentConfig["model"] })}
              disabled={isRunning}
            >
              {MODEL_OPTIONS.map((m) => (
                <option key={m} value={m} className="bg-[#0b1d3a] text-white">{m}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8aacc8] pointer-events-none" />
          </div>
        </div>

        {/* Attack Method */}
        <div>
          <label className="sidebar-label flex items-center gap-2">
            <ShieldAlert className="w-3.5 h-3.5" />
            Attack Method
          </label>
          <div className="relative">
            <select
              className="sidebar-select appearance-none pr-8"
              value={config.attack}
              onChange={(e) => onConfigChange({ attack: e.target.value as ExperimentConfig["attack"] })}
              disabled={isRunning}
            >
              {ATTACK_OPTIONS.map((a) => (
                <option key={a} value={a} className="bg-[#0b1d3a] text-white">{a}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8aacc8] pointer-events-none" />
          </div>
          <p className="mt-1.5 text-[10px] text-[#6a8aaa] leading-relaxed">
            {ATTACK_DESCRIPTIONS[config.attack]}
          </p>
        </div>

        {/* Defense Method */}
        <div>
          <label className="sidebar-label flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            Defense Method
          </label>
          <div className="relative">
            <select
              className="sidebar-select appearance-none pr-8"
              value={config.defense}
              onChange={(e) => onConfigChange({ defense: e.target.value as ExperimentConfig["defense"] })}
              disabled={isRunning}
            >
              {DEFENSE_OPTIONS.map((d) => (
                <option key={d} value={d} className="bg-[#0b1d3a] text-white">{d}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8aacc8] pointer-events-none" />
          </div>
          <p className="mt-1.5 text-[10px] text-[#6a8aaa] leading-relaxed">
            {DEFENSE_DESCRIPTIONS[config.defense]}
          </p>
        </div>

        {/* Poison Ratio Slider */}
        <div>
          <label className="sidebar-label flex items-center gap-2">
            <Percent className="w-3.5 h-3.5" />
            Poison Ratio: <span className="text-[#e6a532] ml-1">{config.poisonRatio}%</span>
          </label>
          <input
            type="range"
            min={1}
            max={50}
            step={1}
            value={config.poisonRatio}
            onChange={(e) => onConfigChange({ poisonRatio: parseInt(e.target.value) })}
            disabled={isRunning}
            className="w-full h-1.5 bg-[#1a3a5c] rounded-none appearance-none cursor-pointer
              [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3
              [&::-webkit-slider-thumb]:bg-[#e6a532] [&::-webkit-slider-thumb]:cursor-pointer"
          />
          <div className="flex justify-between mt-1 text-[9px] text-[#5a7a9a]">
            <span>1%</span>
            <span>10%</span>
            <span>25%</span>
            <span>50%</span>
          </div>
        </div>

        {/* Advanced Settings Toggle */}
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center gap-2 text-[11px] text-[#8aacc8] hover:text-[#e6a532] transition-colors"
        >
          <Settings2 className="w-3.5 h-3.5" />
          {showAdvanced ? "Hide" : "Show"} Advanced Settings
          <ChevronDown className={`w-3 h-3 transition-transform ${showAdvanced ? "rotate-180" : ""}`} />
        </button>

        {showAdvanced && (
          <div className="space-y-4 pb-2">
            {/* Epochs */}
            <div>
              <label className="sidebar-label flex items-center gap-2">
                <Layers className="w-3.5 h-3.5" />
                Epochs: <span className="text-[#e6a532] ml-1">{config.epochs}</span>
              </label>
              <input
                type="range"
                min={10}
                max={200}
                step={10}
                value={config.epochs}
                onChange={(e) => onConfigChange({ epochs: parseInt(e.target.value) })}
                disabled={isRunning}
                className="w-full h-1.5 bg-[#1a3a5c] rounded-none appearance-none cursor-pointer
                  [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3
                  [&::-webkit-slider-thumb]:bg-[#e6a532] [&::-webkit-slider-thumb]:cursor-pointer"
              />
            </div>

            {/* Batch Size */}
            <div>
              <label className="sidebar-label flex items-center gap-2">
                <Hash className="w-3.5 h-3.5" />
                Batch Size
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[32, 64, 128, 256].map((bs) => (
                  <button
                    key={bs}
                    onClick={() => onConfigChange({ batchSize: bs })}
                    disabled={isRunning}
                    className={`py-1.5 text-xs border transition-colors ${
                      config.batchSize === bs
                        ? "border-[#e6a532] bg-[#e6a532]/10 text-[#e6a532]"
                        : "border-[#2a4a7a] text-[#8aacc8] hover:border-[#e6a532]/50"
                    }`}
                  >
                    {bs}
                  </button>
                ))}
              </div>
            </div>

            {/* Target Label */}
            <div>
              <label className="sidebar-label flex items-center gap-2">
                <Beaker className="w-3.5 h-3.5" />
                Target Label (All-to-One)
              </label>
              <input
                type="number"
                min={0}
                max={9}
                value={config.targetLabel}
                onChange={(e) => onConfigChange({ targetLabel: parseInt(e.target.value) })}
                disabled={isRunning}
                className="sidebar-select w-20"
              />
            </div>
          </div>
        )}
      </div>

      {/* Run Button */}
      <div className="px-5 py-4 border-t border-[#1a3a5c] bg-[#0b1d3a]">
        <button
          onClick={onStartExperiment}
          disabled={isRunning}
          className="btn-primary flex items-center justify-center gap-2"
        >
          {isRunning ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Running Experiment...
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              Run Experiment
            </>
          )}
        </button>
        <p className="mt-2.5 text-[10px] text-[#5a7a9a] text-center">
          {isRunning ? "Training in progress..." : "Estimated: 30-120 min on RTX 4060"}
        </p>
      </div>
    </aside>
  );
}
