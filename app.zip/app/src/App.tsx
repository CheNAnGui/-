import { useState, useCallback, useEffect, useRef } from "react";
import { Sidebar } from "@/components/Sidebar";
import { DataFlowCanvas } from "@/components/DataFlowCanvas";
import { MetricsCards } from "@/components/MetricsCards";
import { ConfusionMatrix } from "@/components/ConfusionMatrix";
import { SampleComparison } from "@/components/SampleComparison";
import { TrainingCurves } from "@/components/TrainingCurves";
import { ExperimentLog } from "@/components/ExperimentLog";
import { api } from "@/services/api";
import { defaultExperimentConfig } from "@/types/experiment";
import type { Experiment, ExperimentConfig } from "@/types/experiment";
import { FlaskConical, ServerOff, Server, RefreshCw } from "lucide-react";

const SIMULATION_MODE = true; // Set to false when backend is running

function App() {
  const [config, setConfig] = useState<ExperimentConfig>(defaultExperimentConfig);
  const [experiment, setExperiment] = useState<Experiment | null>(null);
  const [logs, setLogs] = useState<string[]>([
    "[System] Backdoor Defense Lab initialized",
    "[System] Ready to run experiments",
    SIMULATION_MODE ? "[System] Running in simulation mode (no GPU required)" : "[System] Connected to backend API",
  ]);
  const [backendStatus, setBackendStatus] = useState<"connected" | "disconnected" | "checking">(
    SIMULATION_MODE ? "disconnected" : "checking"
  );
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Check backend status
  useEffect(() => {
    if (SIMULATION_MODE) return;
    
    const checkBackend = async () => {
      const info = await api.getGpuInfo();
      setBackendStatus(info ? "connected" : "disconnected");
    };
    checkBackend();
    const interval = setInterval(checkBackend, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleConfigChange = useCallback((newConfig: Partial<ExperimentConfig>) => {
    setConfig((prev) => ({ ...prev, ...newConfig }));
  }, []);

  // Poll experiment status from backend
  const startPolling = useCallback((expId: string) => {
    if (pollRef.current) clearInterval(pollRef.current);
    
    pollRef.current = setInterval(async () => {
      const data = await api.getExperiment(expId);
      if (data) {
        setExperiment({
          id: data.id,
          config: data.config,
          status: data.status as Experiment["status"],
          progress: data.progress,
          metrics: data.metrics || { cleanAcc: 0, attackSuccessRate: 0, defenseAcc: 0, timeCost: 0 },
          confusionMatrix: data.confusion_matrix || Array.from({ length: 10 }, () => Array(10).fill(0)),
          trainingHistory: data.training_history || { epochs: [], cleanAcc: [], attackSuccessRate: [] },
          samples: data.sample_paths || { clean: [], poisoned: [] },
        });
        if (data.log_output) {
          setLogs(data.log_output);
        }
        if (data.status === "completed" || data.status === "failed") {
          if (pollRef.current) clearInterval(pollRef.current);
        }
      }
    }, 2000);
  }, []);

  const handleStartExperiment = useCallback(async () => {
    const newExperiment: Experiment = {
      id: `exp_${Date.now()}`,
      config: { ...config },
      status: "running",
      progress: 0,
      metrics: { cleanAcc: 0, attackSuccessRate: 0, defenseAcc: 0, timeCost: 0 },
      confusionMatrix: Array.from({ length: 10 }, () => Array(10).fill(0)),
      trainingHistory: { epochs: [], cleanAcc: [], attackSuccessRate: [] },
      samples: { clean: [], poisoned: [] },
    };
    setExperiment(newExperiment);
    setLogs((prev) => [
      ...prev,
      `[Experiment ${newExperiment.id}] Started`,
      `[Config] Dataset: ${config.dataset}, Model: ${config.model}`,
      `[Config] Attack: ${config.attack}, Defense: ${config.defense}`,
      `[Config] Poison Ratio: ${config.poisonRatio}%, Epochs: ${config.epochs}`,
    ]);

    // Try to start via backend API
    if (!SIMULATION_MODE && backendStatus === "connected") {
      const result = await api.createExperiment({
        dataset: config.dataset,
        model: config.model,
        attack: config.attack,
        defense: config.defense,
        poisonRatio: config.poisonRatio,
        epochs: config.epochs,
        batchSize: config.batchSize,
        learningRate: config.learningRate,
        targetLabel: config.targetLabel,
      });
      if (result && result.id) {
        startPolling(result.id);
        return;
      }
      setLogs((prev) => [...prev, "[Warning] Backend failed, falling back to simulation"]);
    }
  }, [config, backendStatus, startPolling]);

  // Simulation progress effect
  useEffect(() => {
    if (!experiment || experiment.status !== "running") return;
    if (!SIMULATION_MODE && backendStatus === "connected") return; // Backend handles it

    const interval = setInterval(() => {
      setExperiment((prev) => {
        if (!prev || prev.status !== "running") return prev;
        
        const newProgress = prev.progress + Math.random() * 8;
        if (newProgress >= 100) {
          const cleanAcc = 85 + Math.random() * 10;
          const asr = prev.config.defense === "None" 
            ? 90 + Math.random() * 8 
            : 15 + Math.random() * 25;
          const defenseAcc = prev.config.defense === "None" ? 0 : cleanAcc - (5 + Math.random() * 10);
          
          const cm = Array.from({ length: 10 }, (_, i) => 
            Array.from({ length: 10 }, (_, j) => {
              if (i === j) return Math.floor(Math.random() * 80 + 60);
              if (prev.config.defense === "None" && j === 0) return Math.floor(Math.random() * 30);
              return Math.floor(Math.random() * 5);
            })
          );

          const epochs: number[] = [];
          const cleanAccHist: number[] = [];
          const asrHist: number[] = [];
          for (let e = 0; e <= prev.config.epochs; e += 5) {
            epochs.push(e);
            const progress = e / prev.config.epochs;
            cleanAccHist.push(10 + progress * cleanAcc * 0.9 + Math.random() * 5);
            asrHist.push(prev.config.defense === "None" 
              ? progress * asr * 0.95 + Math.random() * 8
              : Math.max(0, asr * (1 - progress) + Math.random() * 5)
            );
          }

          setLogs((l) => [
            ...l,
            `[Experiment ${prev.id}] Training complete`,
            `[Result] Clean Accuracy: ${cleanAcc.toFixed(2)}%`,
            `[Result] Attack Success Rate: ${asr.toFixed(2)}%`,
            `[Result] Defense Accuracy: ${defenseAcc.toFixed(2)}%`,
            `[System] Experiment finished successfully`,
          ]);

          return {
            ...prev,
            status: "completed",
            progress: 100,
            metrics: { cleanAcc, attackSuccessRate: asr, defenseAcc, timeCost: +(Math.random() * 120 + 60).toFixed(1) },
            confusionMatrix: cm,
            trainingHistory: { epochs, cleanAcc: cleanAccHist, attackSuccessRate: asrHist },
            samples: {
              clean: Array.from({ length: 8 }, (_, i) => `/samples/clean_${i}.png`),
              poisoned: Array.from({ length: 8 }, (_, i) => `/samples/poisoned_${i}.png`),
            },
          };
        }

        if (Math.random() > 0.7) {
          const messages = [
            `Epoch ${Math.floor(newProgress / 100 * prev.config.epochs)}/${prev.config.epochs} - Loss: ${(1.5 - newProgress/100 * 1.3 + Math.random() * 0.2).toFixed(4)}`,
            `Injecting ${prev.config.attack} backdoor trigger...`,
            `Applying ${prev.config.defense} defense mechanism...`,
            `Evaluating model on test set...`,
          ];
          setLogs((l) => [...l, `[Log] ${messages[Math.floor(Math.random() * messages.length)]}`]);
        }

        return { ...prev, progress: Math.min(newProgress, 99) };
      });
    }, 800);

    return () => clearInterval(interval);
  }, [experiment?.status, experiment?.id, backendStatus]);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#f8f9fa]">
      {/* Left Sidebar */}
      <Sidebar
        config={config}
        onConfigChange={handleConfigChange}
        onStartExperiment={handleStartExperiment}
        isRunning={experiment?.status === "running"}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Status Bar */}
        <div className="h-8 bg-white border-b border-[#e0e0e0] flex items-center px-4 justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              {backendStatus === "connected" ? (
                <Server className="w-3 h-3 text-[#4caf50]" />
              ) : (
                <ServerOff className="w-3 h-3 text-[#e6a532]" />
              )}
              <span className="text-[10px] text-[#6c757d] uppercase tracking-wider">
                {backendStatus === "connected" ? "Backend Connected" : "Simulation Mode"}
              </span>
            </div>
            {experiment?.status === "running" && (
              <div className="flex items-center gap-1.5">
                <RefreshCw className="w-3 h-3 text-[#e6a532] animate-spin" />
                <span className="text-[10px] text-[#e6a532]">
                  Progress: {Math.round(experiment.progress)}%
                </span>
                <div className="w-24 h-1.5 bg-[#e8edf3] rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[#e6a532] transition-all duration-500"
                    style={{ width: `${experiment.progress}%` }}
                  />
                </div>
              </div>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            <FlaskConical className="w-3 h-3 text-[#6c757d]" />
            <span className="text-[10px] text-[#6c757d]">v1.0.0</span>
          </div>
        </div>

        {/* Top Section: Metrics + Data Flow Canvas */}
        <div className="h-[42%] flex flex-col border-b border-[#e0e0e0]">
          <MetricsCards experiment={experiment} />
          <div className="flex-1 relative bg-white">
            <DataFlowCanvas 
              isRunning={experiment?.status === "running"} 
              attackType={config.attack}
            />
            <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-3 py-1.5 border border-[#e0e0e0]">
              <span className="text-xs font-medium text-[#6c757d] uppercase tracking-wider">
                Neural Activation Flow
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Section: Visualizations */}
        <div className="flex-1 overflow-auto">
          {!experiment && (
            <div className="h-full flex items-center justify-center">
              <div className="text-center max-w-lg px-6">
                <div className="w-16 h-16 mx-auto mb-4 border-2 border-[#0b1d3a] flex items-center justify-center">
                  <FlaskConical className="w-8 h-8 text-[#0b1d3a]" />
                </div>
                <h3 className="text-lg font-medium text-[#0b1d3a] mb-2" style={{ fontFamily: 'Merriweather, Georgia, serif' }}>
                  Backdoor Defense Laboratory
                </h3>
                <p className="text-sm text-[#6c757d] mb-4">
                  Configure experiment parameters in the sidebar and click "Run Experiment" to start training.
                  Results including confusion matrices, sample comparisons, and training curves will appear here.
                </p>
                <div className="grid grid-cols-3 gap-3 text-left">
                  <div className="bg-white border border-[#e0e0e0] p-3">
                    <span className="text-[10px] text-[#6c757d] uppercase">Step 1</span>
                    <p className="text-xs text-[#0b1d3a] mt-1">Select dataset, model, attack & defense methods</p>
                  </div>
                  <div className="bg-white border border-[#e0e0e0] p-3">
                    <span className="text-[10px] text-[#6c757d] uppercase">Step 2</span>
                    <p className="text-xs text-[#0b1d3a] mt-1">Click "Run Experiment" to start training</p>
                  </div>
                  <div className="bg-white border border-[#e0e0e0] p-3">
                    <span className="text-[10px] text-[#6c757d] uppercase">Step 3</span>
                    <p className="text-xs text-[#0b1d3a] mt-1">View results: confusion matrix, curves, samples</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {experiment && (
            <div className="p-6 space-y-6">
              {/* Confusion Matrix + Training Curves */}
              <div className="grid grid-cols-2 gap-6">
                <div className="academic-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="academic-title text-sm uppercase tracking-wider">Confusion Matrix</h3>
                    <span className="academic-label">{config.dataset} - {config.model}</span>
                  </div>
                  {experiment.status === "running" && experiment.progress < 100 ? (
                    <div className="h-64 skeleton-shimmer rounded-sm" />
                  ) : (
                    <ConfusionMatrix matrix={experiment.confusionMatrix} labels={
                      config.dataset === "MNIST" 
                        ? ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
                        : ["Airplane", "Auto", "Bird", "Cat", "Deer", "Dog", "Frog", "Horse", "Ship", "Truck"]
                    } />
                  )}
                </div>

                <div className="academic-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="academic-title text-sm uppercase tracking-wider">Training Convergence</h3>
                    <span className="academic-label">ACC vs ASR over Epochs</span>
                  </div>
                  {experiment.status === "running" && experiment.progress < 100 ? (
                    <div className="h-64 skeleton-shimmer rounded-sm" />
                  ) : (
                    <TrainingCurves history={experiment.trainingHistory} />
                  )}
                </div>
              </div>

              {/* Sample Comparison */}
              <div className="academic-card">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="academic-title text-sm uppercase tracking-wider">Sample Comparison</h3>
                  <span className="academic-label">Clean vs Poisoned ({config.attack})</span>
                </div>
                {experiment.status === "running" && experiment.progress < 100 ? (
                  <div className="h-40 skeleton-shimmer rounded-sm" />
                ) : (
                  <SampleComparison 
                    cleanSamples={experiment.samples.clean}
                    poisonedSamples={experiment.samples.poisoned}
                    attackType={config.attack}
                  />
                )}
              </div>

              {/* Experiment Log */}
              <div className="academic-card">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="academic-title text-sm uppercase tracking-wider">Execution Log</h3>
                  <span className={`inline-flex items-center px-2 py-0.5 text-xs font-medium border ${
                    experiment.status === "running" 
                      ? "border-[#e6a532] text-[#e6a532]" 
                      : experiment.status === "completed"
                      ? "border-[#4caf50] text-[#4caf50]"
                      : "border-[#6c757d] text-[#6c757d]"
                  }`}>
                    {experiment.status === "running" && (
                      <span className="w-1.5 h-1.5 bg-[#e6a532] rounded-full mr-1.5 animate-pulse" />
                    )}
                    {experiment.status.toUpperCase()}
                  </span>
                </div>
                <ExperimentLog logs={logs} />
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
