const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function fetchApi(path: string, options?: RequestInit) {
  const url = `${API_BASE}${path}`;
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return await response.json();
  } catch (error) {
    console.warn(`API call failed: ${url}`, error);
    return null;
  }
}

export const api = {
  // Experiments
  createExperiment: (config: Record<string, unknown>) =>
    fetchApi("/api/experiments", {
      method: "POST",
      body: JSON.stringify(config),
    }),

  getExperiment: (id: string) => fetchApi(`/api/experiments/${id}`),

  listExperiments: () => fetchApi("/api/experiments"),

  getLogs: (id: string) => fetchApi(`/api/experiments/${id}/logs`),

  deleteExperiment: (id: string) =>
    fetchApi(`/api/experiments/${id}`, { method: "DELETE" }),

  // Info
  getGpuInfo: () => fetchApi("/api/gpu-info"),
  getDatasets: () => fetchApi("/api/datasets"),
  getModels: () => fetchApi("/api/models"),
  getAttacks: () => fetchApi("/api/attacks"),
  getDefenses: () => fetchApi("/api/defenses"),
};

export default api;
