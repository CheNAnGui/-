#!/usr/bin/env python3
"""
GPU Diagnostic Tool for Backdoor Defense Lab
Run this on your Windows machine to verify GPU is properly configured.

Usage:
    python check_gpu.py
"""
import sys
import subprocess


def check_gpu():
    print("=" * 60)
    print("  Backdoor Defense Lab - GPU Diagnostic")
    print("=" * 60)
    print()

    # 1. Check Python version
    print(f"[1] Python version: {sys.version.split()[0]}")
    print()

    # 2. Check PyTorch
    try:
        import torch
        print(f"[2] PyTorch version: {torch.__version__}")
        print(f"    CUDA built with: {torch.version.cuda or 'None'}")
        print(f"    cuDNN: {torch.backends.cudnn.version() if torch.backends.cudnn.is_available() else 'N/A'}")
    except ImportError:
        print("[2] ERROR: PyTorch not installed!")
        print("    Run: pip install torch torchvision")
        return False
    print()

    # 3. Check CUDA availability
    print(f"[3] CUDA available: {torch.cuda.is_available()}")
    if not torch.cuda.is_available():
        print()
        print("    ⚠️  WARNING: CUDA is NOT available!")
        print()
        print("    Possible causes:")
        print("    - PyTorch CPU version installed (most likely)")
        print("    - NVIDIA driver not installed or outdated")
        print("    - CUDA toolkit not installed")
        print()
        print("    To fix (Windows + RTX 4060):")
        print("    1. Uninstall current PyTorch:")
        print("       pip uninstall torch torchvision torchaudio")
        print()
        print("    2. Install CUDA 12.4 version:")
        print("       pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124")
        print()
        print("    3. Verify NVIDIA driver:")
        print("       - Open Device Manager → Display adapters")
        print("       - Should see 'NVIDIA GeForce RTX 4060 Laptop GPU'")
        print("       - Download latest driver from nvidia.com/drivers")
        return False
    print()

    # 4. GPU details
    print(f"[4] GPU Count: {torch.cuda.device_count()}")
    for i in range(torch.cuda.device_count()):
        name = torch.cuda.get_device_name(i)
        props = torch.cuda.get_device_properties(i)
        vram = props.total_memory / (1024 ** 3)
        print(f"    GPU {i}: {name}")
        print(f"    VRAM: {vram:.1f} GB")
        print(f"    Compute Capability: {props.major}.{props.minor}")
    print()

    # 5. Quick VRAM test
    print("[5] VRAM allocation test:")
    try:
        x = torch.randn(1000, 1000).cuda()
        used = torch.cuda.memory_allocated(0) / (1024 ** 2)
        print(f"    Allocated test tensor: OK ({used:.1f} MB used)")
        del x
        torch.cuda.empty_cache()
        print("    Cleanup: OK")
    except Exception as e:
        print(f"    ERROR: {e}")
        return False
    print()

    # 6. Check training readiness
    print("[6] Training readiness check:")
    try:
        # Quick forward pass test
        import torch.nn as nn
        model = nn.Sequential(
            nn.Linear(10, 64),
            nn.ReLU(),
            nn.Linear(64, 10)
        ).cuda()
        x = torch.randn(32, 10).cuda()
        y = model(x)
        loss = y.sum()
        loss.backward()
        print(f"    Forward + backward pass: OK")
        print(f"    Output shape: {y.shape}")
    except Exception as e:
        print(f"    ERROR: {e}")
        return False
    print()

    # 7. Check nvidia-smi
    print("[7] nvidia-smi check:")
    try:
        result = subprocess.run(
            ["nvidia-smi"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            # Parse GPU name from output
            for line in result.stdout.split('\n'):
                if 'RTX' in line or 'GeForce' in line or 'NVIDIA' in line:
                    print(f"    {line.strip()}")
        else:
            print("    nvidia-smi not found (optional, PyTorch detection works)")
    except FileNotFoundError:
        print("    nvidia-smi not found (optional, PyTorch detection works)")
    except Exception as e:
        print(f"    nvidia-smi error: {e}")
    print()

    print("=" * 60)
    print("  ✓ GPU is ready for training!")
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = check_gpu()
    if not success:
        print()
        print("=" * 60)
        print("  ✗ GPU check failed - see above for fix instructions")
        print("=" * 60)
        sys.exit(1)
