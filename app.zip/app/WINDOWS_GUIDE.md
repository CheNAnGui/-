# Windows 运行指南

## 最简单的运行方式

### 方式一：纯前端演示（无需 Python，立即可看效果）

```
app/
└── dist/
    └── index.html   <-- 直接用浏览器打开这个文件
```

**步骤**：
1. 打开文件资源管理器
2. 进入 `app/dist/` 文件夹
3. 双击 `index.html`

> 这是纯静态演示，所有训练过程是模拟的，不需要任何后端或 GPU。

---

### 方式二：完整全栈（需要 Python + PyTorch）

**开两个命令行窗口**分别运行：

#### 窗口 1：启动后端
```cmd
cd F:\LEARN_INVOLVE_EXTRA\网络信息安全\机器学习后门攻防\Kimi_Agent_后门攻防实验\app
start_windows.bat
```

或手动输入：
```cmd
cd F:\LEARN_INVOLVE_EXTRA\网络信息安全\机器学习后门攻防\Kimi_Agent_后门攻防实验\app
set PYTHONPATH=%CD%
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

#### 窗口 2：启动前端（静态文件服务器）
```cmd
cd F:\LEARN_INVOLVE_EXTRA\网络信息安全\机器学习后门攻防\Kimi_Agent_后门攻防实验\app
dist_server.bat
```

或手动输入：
```cmd
cd F:\LEARN_INVOLVE_EXTRA\网络信息安全\机器学习后门攻防\Kimi_Agent_后门攻防实验\app\dist
python -m http.server 3000
```

然后浏览器打开：http://localhost:3000

---

### 方式三：一键脚本（自动开两个窗口）

```cmd
cd F:\LEARN_INVOLVE_EXTRA\网络信息安全\机器学习后门攻防\Kimi_Agent_后门攻防实验\app
python start.py
```

这会自动：
1. 开一个窗口运行后端 (localhost:8000)
2. 开一个窗口运行前端静态服务器 (localhost:3000)

---

## 首次环境配置

### 1. 安装 Python 依赖

确保你已经安装了 Python 3.10+ 和 PyTorch (CUDA 版本)。

```cmd
cd F:\LEARN_INVOLVE_EXTRA\网络信息安全\机器学习后门攻防\Kimi_Agent_后门攻防实验\app
pip install -r backend/requirements.txt
```

### 2. 检查 GPU 是否可用

```cmd
python -c "import torch; print('CUDA:', torch.cuda.is_available()); print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'None')"
```

应该输出你的 RTX 4060 Laptop。

---

## 运行实验

### 单次实验流程

1. 打开浏览器访问 http://localhost:3000
2. 在左侧边栏选择参数：
   - Dataset: `CIFAR-10`
   - Model: `ResNet-18`
   - Attack: `BadNets`
   - Defense: `None` (先跑攻击基线)
   - Poison Ratio: `10`
   - Epochs: `50`
3. 点击 **Run Experiment**
4. 等待训练完成（约 20-40 分钟）
5. 查看右侧的混淆矩阵、训练曲线、样本对比

### 推荐实验批次（每次 2-3 小时）

**第 1 批 - 攻击基线（约 2 小时）**：
- CIFAR-10 + ResNet-18 + BadNets + None (10%)
- CIFAR-10 + ResNet-18 + Blended + None (10%)
- CIFAR-10 + ResNet-18 + WaNet + None (10%)

**第 2 批 - 防御对比（约 2.5 小时）**：
- CIFAR-10 + ResNet-18 + BadNets + Fine-Pruning (10%)
- CIFAR-10 + ResNet-18 + BadNets + FT-SAM (10%)
- CIFAR-10 + ResNet-18 + BadNets + STRIP (10%)

**第 3 批 - 扩展验证（约 2.5 小时）**：
- CIFAR-10 + ResNet-18 + SIG + Fine-Pruning (5%)
- MNIST + ResNet-18 + BadNets + FT-SAM (10%)
- GTSRB + ResNet-18 + Blended + Fine-Pruning (10%)

---

## GPU 显存优化（RTX 4060 8GB）

如果训练时报 OOM (显存不足)，调整以下参数：

| 参数 | 默认值 | OOM 时建议 |
|------|--------|-----------|
| Batch Size | 128 | 64 |
| Epochs | 50 | 30 |
| Dataset | CIFAR-10 | MNIST (更小) |

在边栏展开 **Advanced Settings** 进行修改。

---

## 常见问题

**Q: 双击 index.html 后界面空白？**
A: 这是浏览器的 CORS 安全策略。请用以下方式之一：
- 方式一：`cd dist && python -m http.server 3000` 然后访问 localhost:3000
- 方式二：安装 VS Code 的 "Live Server" 插件，右键 index.html → Open with Live Server

**Q: 后端启动后前端显示 "Simulation Mode"？**
A: 修改 `src/App.tsx` 第 20 行：将 `const SIMULATION_MODE = true;` 改为 `const SIMULATION_MODE = false;`，然后重新构建前端：`npm run build`

**Q: pip install 时某些包安装失败？**
A: 核心只需要这几个包：
```cmd
pip install torch torchvision fastapi uvicorn numpy scikit-learn matplotlib tqdm
```
