#!/usr/bin/env python3
"""
Unified launcher for the Backdoor Defense Lab.
Starts both the Python backend and optionally the frontend.

Usage:
    python start.py --backend-only    # Start only the backend API
    python start.py --frontend-only  # Start only the frontend (static build)
    python start.py                  # Start both (default)

Windows:
    python start.py --backend-only
    # Then open dist/index.html directly, or run: npx serve dist
"""
import os
import sys
import subprocess
import argparse
import time
import platform


def get_npm_cmd():
    """Get npm command for current platform."""
    if platform.system() == "Windows":
        # Try npm.cmd first on Windows
        for cmd in ["npm.cmd", "npm"]:
            try:
                subprocess.run([cmd, "--version"], capture_output=True, check=True)
                return cmd
            except (subprocess.CalledProcessError, FileNotFoundError):
                continue
    return "npm"


def start_backend(port=8000):
    """Start the Python FastAPI backend."""
    print("[Launcher] Starting Python backend...")
    env = os.environ.copy()
    env["PYTHONPATH"] = os.path.dirname(os.path.abspath(__file__))
    
    cmd = [sys.executable, "-m", "uvicorn", "backend.main:app", 
           "--host", "0.0.0.0", "--port", str(port)]
    
    if platform.system() == "Windows":
        proc = subprocess.Popen(cmd, env=env, cwd=os.path.dirname(os.path.abspath(__file__)),
                                creationflags=subprocess.CREATE_NEW_CONSOLE)
    else:
        proc = subprocess.Popen(cmd, env=env, cwd=os.path.dirname(os.path.abspath(__file__)))
    return proc


def start_frontend_static():
    """Start a static file server for the built frontend."""
    dist_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dist")
    if not os.path.exists(dist_dir):
        print(f"[Warning] dist/ folder not found at {dist_dir}")
        print("[Warning] Please run 'npm run build' first, or open dist/index.html directly")
        return None
    
    print("[Launcher] Starting static file server for frontend...")
    print("[Launcher] Serving dist/ folder at http://localhost:3000")
    
    # Use Python's built-in http.server to serve the dist folder
    cmd = [sys.executable, "-m", "http.server", "3000", "--directory", dist_dir]
    
    if platform.system() == "Windows":
        proc = subprocess.Popen(cmd, creationflags=subprocess.CREATE_NEW_CONSOLE)
    else:
        proc = subprocess.Popen(cmd)
    return proc


def start_frontend_dev():
    """Start the frontend dev server (requires npm)."""
    npm = get_npm_cmd()
    print(f"[Launcher] Starting frontend dev server (npm={npm})...")
    
    cmd = [npm, "run", "dev"]
    
    if platform.system() == "Windows":
        proc = subprocess.Popen(cmd, cwd=os.path.dirname(os.path.abspath(__file__)),
                                creationflags=subprocess.CREATE_NEW_CONSOLE, shell=True)
    else:
        proc = subprocess.Popen(cmd, cwd=os.path.dirname(os.path.abspath(__file__)))
    return proc


def main():
    parser = argparse.ArgumentParser(description="Backdoor Defense Lab Launcher")
    parser.add_argument("--backend-only", action="store_true", help="Start only backend")
    parser.add_argument("--frontend-only", action="store_true", help="Start only frontend (static)")
    parser.add_argument("--frontend-dev", action="store_true", help="Start frontend dev server (needs npm)")
    parser.add_argument("--backend-port", type=int, default=8000, help="Backend port (default: 8000)")
    parser.add_argument("--no-backend", action="store_true", help="Skip backend")
    parser.add_argument("--no-frontend", action="store_true", help="Skip frontend")
    args = parser.parse_args()

    processes = []

    try:
        if args.frontend_dev:
            processes.append(("frontend", start_frontend_dev()))
        elif args.frontend_only:
            proc = start_frontend_static()
            if proc:
                processes.append(("frontend", proc))
        elif args.backend_only:
            processes.append(("backend", start_backend(args.backend_port)))
        else:
            if not args.no_backend:
                processes.append(("backend", start_backend(args.backend_port)))
                time.sleep(2)
            if not args.no_frontend:
                proc = start_frontend_static()
                if proc:
                    processes.append(("frontend", proc))

        print("\n" + "=" * 60)
        print("  Backdoor Defense Lab is running!")
        print("=" * 60)
        if not args.no_frontend and not args.backend_only:
            print("  Frontend: http://localhost:3000")
            print("  Or open:  dist/index.html (direct file)")
        if not args.no_backend and not args.frontend_only:
            print(f"  Backend API: http://localhost:{args.backend_port}")
            print(f"  API Docs:    http://localhost:{args.backend_port}/docs")
        print("=" * 60)
        
        if platform.system() == "Windows":
            print("\n  [Windows] Each service opened in a separate console window.")
            print("  Close those windows to stop the services.")
        else:
            print("\n  Press Ctrl+C to stop all services.")
        print()

        # Wait for processes
        while True:
            time.sleep(1)
            for name, proc in processes:
                if proc.poll() is not None:
                    print(f"[Warning] {name} process exited with code {proc.returncode}")
                    return

    except KeyboardInterrupt:
        print("\n[Launcher] Shutting down...")
        for name, proc in processes:
            print(f"[Launcher] Stopping {name}...")
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
        print("[Launcher] All services stopped.")


if __name__ == "__main__":
    main()
