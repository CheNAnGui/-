@echo off
chcp 65001 >nul
title Backdoor Defense Lab - Backend
echo ============================================
echo   Backdoor Defense Lab - Backend Server
echo ============================================
echo.
echo Starting Python backend...
echo API will be at: http://localhost:8000
echo API Docs:      http://localhost:8000/docs
echo.

set PYTHONPATH=%~dp0
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000

pause
